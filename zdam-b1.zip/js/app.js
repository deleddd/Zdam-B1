/* Zdam B1 — app logic. Data comes from words.js and content.js */
(function(){
"use strict";
/* ============ DATA PREP ============ */
const W=window.WORDS_RAW.split("\n").map(l=>{const[t,pl,ru,ex,exru,hint]=l.split("|");const m=ex.match(/\{(.+?)\}/);return{id:pl,t,pl,ru,ex,exru,hint:hint||"",ans:m?m[1]:pl}});
const WI=Object.fromEntries(W.map(w=>[w.id,w]));
const DECKS=[...new Set(W.map(w=>w.t))];
const GTAGS=[...new Set(GRAM.map(g=>g[0]))];

const PLAN=[
["Старт: формат экзамена",[["Прочитать, как устроен экзамен","test/info"],["Слова: Urząd","words/Urząd"],["Грамматика: Biernik","gram/mc/Biernik"],["Аудирование: «Na dworcu»","practice/audio/0"]]],
["Dopełniacz",[["Грамматика: Dopełniacz","gram/mc/Dopełniacz"],["Слова: Praca","words/Praca"],["Найди ошибку","gram/errors"],["Диктант: 3 фразы","practice/dict"]]],
["Narzędnik",[["Грамматика: Narzędnik","gram/mc/Narzędnik"],["Слова: Ложные друзья","words/Ложные друзья"],["Говорение: «Przedstaw się»","practice/speak/0"],["Чтение: текст 1","practice/read/0"]]],
["Miejscownik: w, na, o",[["Грамматика: Miejscownik","gram/mc/Miejscownik"],["Слова: Zdrowie","words/Zdrowie"],["Аудирование: у врача","practice/audio/1"],["Формы слов: 10 заданий","gram/forms"]]],
["Celownik",[["Грамматика: Celownik","gram/mc/Celownik"],["Слова: Dom","words/Dom"],["Письмо: приглашение другу","practice/write/0"],["Порядок слов","gram/order"]]],
["Числительные",[["Грамматика: Liczebniki","gram/mc/Liczebniki"],["Слова: Rodzina i ludzie","words/Rodzina i ludzie"],["Повтор вслух: 5 фраз","practice/shadow"],["Чтение: текст 2","practice/read/1"]]],
["Мини-экзамен №1",[["Пробный экзамен по частям","test"],["Разобрать ошибки","gram/mc/Ошибки"],["Игра «Пары»","words/pairs"]]],
["Вид глагола: прошлое",[["Грамматика: Aspekt","gram/mc/Aspekt"],["Говорение: последний отпуск","practice/speak/2"],["Слова: Podróże","words/Podróże"],["Аудирование: квартира","practice/audio/2"]]],
["Вид глагола: будущее",[["Грамматика: Aspekt","gram/mc/Aspekt"],["Письмо: о новой работе","practice/write/4"],["Формы слов","gram/forms"],["Слова: Czasowniki","words/Czasowniki"]]],
["Глаголы движения",[["Грамматика: Ruch","gram/mc/Ruch"],["Слова: Miasto","words/Miasto"],["Говорение: жильё и район","practice/speak/1"],["Чтение: смена расписания","practice/read/3"]]],
["Tryb przypuszczający",[["Грамматика: Tryb","gram/mc/Tryb"],["Говорение: «Co byś zrobił?»","practice/speak/10"],["Слова: Wolny czas","words/Wolny czas"],["Найди ошибку","gram/errors"]]],
["Предлоги",[["Грамматика: Przyimki","gram/mc/Przyimki"],["Слова: Jedzenie","words/Jedzenie"],["Аудирование: прогноз погоды","practice/audio/3"],["Порядок слов","gram/order"]]],
["Залог и разное",[["Грамматика: Inne","gram/mc/Inne"],["Повтор вслух: 5 фраз","practice/shadow"],["Слова: Spójniki","words/Spójniki"],["Чтение: правила спортзала","practice/read/4"]]],
["Мини-экзамен №2",[["Пробный экзамен по частям","test"],["Разобрать ошибки","gram/mc/Ошибки"],["Игра «Пары»","words/pairs"]]],
["Чтение объявлений",[["Чтение: объявления","practice/read/7"],["Слова: Media i technologia","words/Media i technologia"],["Формы слов","gram/forms"]]],
["Формальное письмо",[["Письмо: e-mail в администрацию","practice/write/1"],["Сравнить с образцом","practice/write/1"],["Слова: Pogoda i natura","words/Pogoda i natura"]]],
["Чтение статей",[["Чтение: работа удалённо","practice/read/2"],["Чтение: велосипеды","practice/read/6"],["Слова: Edukacja","words/Edukacja"]]],
["Текст-мнение",[["Письмо: мнение","practice/write/3"],["Говорение: удалённая работа","practice/speak/3"],["Слова: Przymiotniki","words/Przymiotniki"]]],
["Аудирование",[["Аудирование: все диалоги","practice/audio"],["Диктант: 5 фраз","practice/dict"],["20 минут польского радио","practice/audio"]]],
["Претензии и жалобы",[["Письмо: рекламация","practice/write/2"],["Аудирование: рекламация","practice/audio/4"],["Говорение: возврат товара","practice/speak/5"]]],
["Мини-экзамен №3",[["Пробный экзамен по частям","test"],["Разобрать ошибки","gram/mc/Ошибки"]]],
["Ролевые диалоги",[["Говорение: у врача","practice/speak/4"],["Говорение: шумный сосед","practice/speak/9"],["Аудирование: в управлении","practice/audio/7"],["Слова: Uczucia i charakter","words/Uczucia i charakter"]]],
["Мнения вслух",[["Говорение: город или деревня","practice/speak/7"],["Говорение: соцсети","practice/speak/11"],["Грамматика: всё","gram/mc"],["Порядок слов","gram/order"]]],
["Письмо на время",[["Письмо: объявление за 20 минут","practice/write/5"],["Письмо: курс языка","practice/write/6"],["Слова: повторение","words"]]],
["Работа и быт",[["Говорение: о работе","practice/speak/12"],["Аудирование: собеседование","practice/audio/6"],["Чтение: письмо подруги","practice/read/5"]]],
["Полная симуляция",[["Пробный экзамен по частям","test"],["Говорение: 2 случайные темы","practice/speak"]]],
["Работа над ошибками",[["Грамматика: ошибки","gram/mc/Ошибки"],["Найди ошибку","gram/errors"],["Слова: повторение","words"]]],
["Симуляция №2",[["Пробный экзамен по частям","test"],["Говорение: «Przedstaw się»","practice/speak/0"],["Письмо: извинение","practice/write/7"]]],
["Лёгкий повтор",[["Слова: повторение","words"],["Игра «Пары»","words/pairs"],["Шпаргалка по грамматике","gram/cheat"]]],
["День перед экзаменом",[["Проверить документ, адрес, время","test/info"],["Пролистать образцы писем","practice/write"],["Лечь спать вовремя","test/info"]]]
];

/* ============ STATE ============ */
const KEY="zdamb1-v2",DAY=864e5,INT=[0,1,2,4,7,12,20];
let S={route:"home",start:null,exam:"",done:{},srs:{},miss:[],draft:"",sel:null,log:{},newPer:7,deck:null,best:null,mocks:[]};
try{const r=localStorage.getItem(KEY);if(r)S=Object.assign(S,JSON.parse(r))}catch(e){}
const ymd=(d=new Date())=>d.toLocaleDateString("sv-SE");
if(!S.start)S.start=ymd();
if(!S.mocks)S.mocks=[];
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
const pick=(a,n)=>shuffle(a).slice(0,n);
const today=()=>{const k=ymd();return S.log[k]||(S.log[k]={xp:0,w:0,g:0,d:0,s:0,sh:0})};
function addXP(n,field,inc=1){const t=today();t.xp+=n;if(field)t[field]=(t[field]||0)+inc;save();renderPills()}
function streak(){let n=0,d=new Date();if(!(S.log[ymd(d)]?.xp))d=new Date(d-DAY);while(S.log[ymd(d)]?.xp){n++;d=new Date(d-DAY)}return n}
function dayIndex(){const d=Math.floor((Date.now()-new Date(S.start+"T00:00").getTime())/DAY);return Math.min(29,Math.max(0,d))}
function daysToExam(){if(!S.exam)return null;return Math.ceil((new Date(S.exam+"T00:00").getTime()-Date.now())/DAY)}
const dueWords=()=>W.filter(w=>S.srs[w.id]&&S.srs[w.id].due<=Date.now());
const lvl=id=>S.srs[id]?S.srs[id].l:0;
const GOALS=[["w",20,"Слова","words"],["g",15,"Грамматика","gram/mc"],["d",5,"Аудирование","practice/audio"],["s",1,"Говорение","practice/speak"]];
const XPGOAL=200;

/* answer checking */
const DIA={"ą":"a","ć":"c","ę":"e","ł":"l","ń":"n","ó":"o","ś":"s","ź":"z","ż":"z"};
const low=s=>s.toLowerCase().replace(/[.,!?;:„”"–—]/g," ").replace(/\s+/g," ").trim();
const strip=s=>s.replace(/[ąćęłńóśźż]/g,c=>DIA[c]);
function check(inp,targets){const a=low(inp);if(!a)return"no";const T=String(targets).split("|");
  if(T.some(t=>low(t)===a))return"ok";if(T.some(t=>strip(low(t))===strip(a)))return"accent";return"no"}
const KEYS=dis=>`<div class="keys">${"ąćęłńóśźż".split("").map(c=>`<button type="button" data-key="${c}" ${dis?"disabled":""}>${c}</button>`).join("")}</div>`;
let lastInp=null;
document.addEventListener("focusin",e=>{if(e.target.matches&&e.target.matches("input[type=text],textarea"))lastInp=e.target});
document.addEventListener("pointerdown",e=>{if(e.target.closest("[data-key]"))e.preventDefault()});
document.addEventListener("click",e=>{const b=e.target.closest("[data-key]");if(!b)return;const box=b.closest("[data-keybox]")||document;
  const inp=(lastInp&&document.contains(lastInp)&&box.contains(lastInp)&&!lastInp.disabled)?lastInp:box.querySelector("input[type=text]:not([disabled]),textarea");if(!inp)return;
  const s=inp.selectionStart??inp.value.length;inp.value=inp.value.slice(0,s)+b.dataset.key+inp.value.slice(inp.selectionEnd??s);inp.dispatchEvent(new Event("input"));inp.focus();inp.selectionStart=inp.selectionEnd=s+1});

/* ============ SPEECH ============ */
let plVoice=null,nVoices=0,ttsHeard=false,ttsFailed=false;
const ttsOK=(()=>{try{return "speechSynthesis" in window&&typeof SpeechSynthesisUtterance!=="undefined"}catch(e){return false}})();
function loadVoices(){try{const v=speechSynthesis.getVoices();nVoices=v.length;plVoice=v.find(x=>/^pl/i.test(x.lang))||null}catch(e){}}
try{loadVoices();speechSynthesis.addEventListener("voiceschanged",loadVoices);setTimeout(loadVoices,800);setTimeout(()=>{loadVoices();if(R.tab==="home"||R.tab==="words")render()},2500)}catch(e){}
let ttsUnlocked=false;
document.addEventListener("pointerdown",()=>{if(ttsUnlocked||!ttsOK)return;ttsUnlocked=true;try{const u=new SpeechSynthesisUtterance(" ");u.volume=0;speechSynthesis.speak(u)}catch(e){}},{capture:true});
function say(t,rate,onend){if(!ttsOK)return;try{
  const s=speechSynthesis;if(!plVoice)loadVoices();
  const u=new SpeechSynthesisUtterance(String(t).replace(/[{}]/g,""));u.lang="pl-PL";if(plVoice)u.voice=plVoice;u.rate=rate||.9;
  u.onstart=()=>{ttsHeard=true};u.onend=()=>{onend&&onend()};
  u.onerror=e=>{if(e.error!=="interrupted"&&e.error!=="canceled"){ttsFailed=true;showTtsNote()}};
  const go=()=>{try{s.resume()}catch(e){}s.speak(u)};
  if(s.speaking||s.pending){s.cancel();setTimeout(go,80)}else go();
  setTimeout(()=>{if(!ttsHeard&&!s.speaking){ttsFailed=true;showTtsNote()}},2500);
}catch(e){ttsFailed=true;showTtsNote()}}
function sayAll(lines,rate){let i=0;const next=()=>{if(i<lines.length)say(lines[i++],rate,()=>setTimeout(next,450))};next()}
function ttsNoteHTML(){return `<div class="hint" id="ttsnote">Звук не играет. Открой приложение в Safari или Chrome — там голос работает.${ttsOK&&nVoices&&!plVoice?" И добавь польский голос: настройки телефона → Озвучивание / Синтез речи → польский.":""}</div>`}
function showTtsNote(){if(document.getElementById("ttsnote"))return;const st=document.querySelector(".stage")||$("#app");if(st)st.insertAdjacentHTML("afterbegin",ttsNoteHTML())}
const SPK=`<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 4V5L7 9H3zm13.5 3a4.5 4.5 0 0 0-2.5-4v8a4.5 4.5 0 0 0 2.5-4zM14 3.2v2.1a7 7 0 0 1 0 13.4v2.1a9 9 0 0 0 0-17.6z"/></svg>`;
const sayBtn=(t,cls="")=>ttsOK?`<button class="say ${cls}" data-say="${esc(t)}" aria-label="Произнести">${SPK}</button>`:"";
document.addEventListener("click",e=>{const b=e.target.closest("[data-say]");if(b){e.stopPropagation();say(b.dataset.say,b.dataset.rate?+b.dataset.rate:.9)}});

/* ============ SHELL ============ */
const NAV=[["home","Сегодня",'<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'],
["words","Слова",'<rect x="4" y="3" width="13" height="17" rx="2"/><path d="M8 7h5M8 11h5"/><path d="M20 7v13a1 1 0 0 1-1 1H8"/>'],
["gram","Грамматика",'<path d="M4 20l6-16h2l6 16M7 14h10"/>'],
["practice","Практика",'<path d="M12 3a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V6a3 3 0 0 1 3-3z"/><path d="M19 11a7 7 0 0 1-14 0M12 18v3"/>'],
["test","Экзамен",'<path d="M9 4h6l1 2h3v15H5V6h3z"/><path d="M9 13l2 2 4-4"/>']];
let R={tab:"home",a:null,b:null,c:null};
const parse=route=>{const[tab,a,b,c]=String(route).split("/");return{tab,a:a??null,b:b??null,c:c??null}};
function go(route){R=parse(route);S.route=route;save();sess=null;render();window.scrollTo(0,0)}
function renderPills(){const t=today();$("#pills").innerHTML=`<span class="pill" title="Дней подряд"><svg viewBox="0 0 24 24" fill="var(--accent)"><path d="M12 2s5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 1-3s0 2 2 2c0-4 2-9 2-9z"/></svg>${streak()}</span><span class="pill" title="Очки сегодня">${t.xp} XP</span>`}
function renderNav(){$("#navin").innerHTML=NAV.map(([k,l,ic])=>`<button data-nav="${k}" aria-current="${R.tab===k}"><svg viewBox="0 0 24 24">${ic}</svg>${l}</button>`).join("");
  $("#nav").hidden=!!sess;document.body.classList.toggle("focus",!!sess)}
document.addEventListener("click",e=>{const b=e.target.closest("[data-nav]");if(b)return go(b.dataset.nav);const r=e.target.closest("[data-route]");if(r)go(r.dataset.route)});
function render(){renderPills();renderNav();$("#sheet").innerHTML="";const el=$("#app");el.innerHTML="";if(sess)return VIEWS.session(el);(VIEWS[R.tab]||VIEWS.home)(el)}
const seg=(items,cur,prefix)=>`<div class="seg">${items.map(([k,l])=>`<button data-route="${prefix}/${k}" aria-pressed="${cur===k}">${l}</button>`).join("")}</div>`;
const VIEWS={};
let sess=null;

/* ============ HOME ============ */
VIEWS.home=el=>{
  const cur=dayIndex(),sel=S.sel??cur,t=today(),due=dueWords().length,fresh=W.filter(w=>!S.srs[w.id]).length;
  const pct=Math.min(1,t.xp/XPGOAL),C=2*Math.PI*40,dte=daysToExam(),learned=W.filter(w=>lvl(w.id)>=4).length;
  const doneCount=d=>PLAN[d][1].filter((_,i)=>S.done[d+"-"+i]).length,p=PLAN[sel];
  const lastMock=S.mocks[S.mocks.length-1];
  el.innerHTML=`
  <section class="panel hero">
    <div class="hero-top">
      <div class="ring"><svg viewBox="0 0 92 92"><circle cx="46" cy="46" r="40" stroke="color-mix(in srgb,var(--card) 16%,transparent)" stroke-width="9" fill="none"/><circle cx="46" cy="46" r="40" stroke="var(--accent)" stroke-width="9" fill="none" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-pct)}"/></svg><b>${t.xp}<small>из ${XPGOAL} XP</small></b></div>
      <div style="min-width:0"><div class="label" style="color:inherit;opacity:.65">День ${cur+1} из 30${dte!=null?` · до экзамена ${dte} дн.`:""}</div>
      <h1 style="margin-top:4px">${pct>=1?"Цель дня выполнена":t.xp?"Хороший темп, продолжай":"Dzień dobry! Начнём?"}</h1>
      <p class="small muted" style="margin-top:4px">Выучено ${learned} из ${W.length} слов${lastMock?` · последний экзамен ${lastMock.total}%`:""}</p></div>
    </div>
    <div class="goals">${GOALS.map(([k,n,l,r])=>{const v=Math.min(n,t[k]||0);return `<button class="goal ${v>=n?"ok":""}" data-route="${r}"><span>${l}<em>${v}/${n}</em></span><div class="mini"><i style="width:${v/n*100}%"></i></div></button>`}).join("")}</div>
  </section>
  <button class="cta" id="start"><div><b>${due?"Повторить слова":"Учить новые слова"}</b><span>${due} к повторению · ${Math.min(S.newPer,fresh)} новых</span></div><span class="arr">→</span></button>
  <section class="panel">
    <div class="row between"><div><div class="label">${sel===cur?"План на сегодня":"День "+(sel+1)}</div><h2 style="margin-top:2px">${esc(p[0])}</h2></div><span class="score small muted">${doneCount(sel)}/${p[1].length}</span></div>
    <div>${p[1].map((tk,i)=>{const id=sel+"-"+i,d=!!S.done[id];return `<div class="task ${d?"done":""}"><input type="checkbox" id="t${id}" data-done="${id}" ${d?"checked":""}><label for="t${id}">${esc(tk[0])}</label><button class="go" data-route="${esc(tk[1])}">Открыть</button></div>`}).join("")}</div>
    <div class="weeks">${[0,7,14,21,28].map(s=>`<div class="week">${PLAN.slice(s,s+7).map((_,k)=>{const d=s+k,c=doneCount(d),n=PLAN[d][1].length;return `<button class="dot ${c===n?"full":c?"part":""} ${d===cur?"cur":""} ${d===sel&&sel!==cur?"sel":""}" data-sel="${d}" aria-label="День ${d+1}">${d+1}</button>`}).join("")}</div>`).join("")}</div>
    <p class="xs muted">Неделя 1 — падежи · 2 — глаголы · 3 — чтение и письмо · 4 — говорение и симуляции</p>
  </section>
  <section class="panel">
    <h2>Настройки</h2>
    <div class="row between"><label for="examd" class="small">Дата экзамена</label><input type="date" id="examd" value="${S.exam}"></div>
    <div class="row between"><label for="startd" class="small">Начало плана</label><input type="date" id="startd" value="${S.start}"></div>
    <div class="row between"><label for="newper" class="small">Новых слов за сессию</label><select id="newper">${[4,7,10,15].map(n=>`<option ${S.newPer===n?"selected":""}>${n}</option>`).join("")}</select></div>
    <div class="row between"><span class="small">Звук: ${!ttsOK?"недоступен":!nVoices?"голоса загружаются":plVoice?"польский голос найден":"нет польского голоса"}</span><button class="btn" data-say="Dzień dobry! Uczę się polskiego.">Проверить звук</button></div>
    <div class="row between"><span class="small muted">Прогресс хранится в этом браузере</span><button class="btn" id="reset">Сбросить</button></div>
  </section>`;
  $("#start").onclick=()=>startSession();
  el.querySelectorAll("[data-done]").forEach(c=>c.onchange=()=>{c.checked?S.done[c.dataset.done]=1:delete S.done[c.dataset.done];save();render()});
  el.querySelectorAll("[data-sel]").forEach(b=>b.onclick=()=>{S.sel=+b.dataset.sel===cur?null:+b.dataset.sel;save();render()});
  $("#examd").onchange=e=>{S.exam=e.target.value;save();render()};
  $("#startd").onchange=e=>{if(e.target.value){S.start=e.target.value;S.sel=null;save();render()}};
  $("#newper").onchange=e=>{S.newPer=+e.target.value;save();render()};
  $("#reset").onclick=e=>{const b=e.target;if(b.dataset.sure){try{localStorage.removeItem(KEY)}catch(x){}location.reload()}else{b.dataset.sure=1;b.textContent="Точно? Всё удалится";b.classList.add("dark")}};
};

/* ============ WORDS: SRS ============ */
function revType(w){const l=lvl(w.id);const o=l<=2?["mc_ru","cloze","mc_ru"]:["type","cloze","cloze"];if(l>=3&&ttsOK)o.push("listen");return o[Math.random()*o.length|0]}
function startSession(deck){
  const due=dueWords().sort((a,b)=>S.srs[a.id].due-S.srs[b.id].due).slice(0,25);
  const fresh=W.filter(w=>!S.srs[w.id]&&(!deck||w.t===deck)).slice(0,S.newPer);
  const rev=shuffle(due.map(w=>({type:revType(w),id:w.id})));
  const chunks=[];
  for(let i=0;i<fresh.length;i+=3){const g=fresh.slice(i,i+3).map(w=>w.id);
    chunks.push([...g.map(id=>({type:"intro",id,isNew:1})),...shuffle(g).map(id=>({type:"mc_pl",id,isNew:1})),...shuffle(g).map(id=>({type:"mc_ru",id,isNew:1})),...shuffle(g).map(id=>({type:"cloze",id,isNew:1,last:1}))])}
  const q=[];let ri=0;for(const c of chunks){q.push(...rev.slice(ri,ri+3));ri+=3;q.push(...c)}q.push(...rev.slice(ri));
  sess=q.length?{q,pos:0,ok:0,n:0,xp:0,newIds:fresh.map(w=>w.id),failed:new Set(),fb:null,pick:null,input:""}:{q:[],empty:true};
  render();window.scrollTo(0,0);
}
function distract(w,field){const same=shuffle(W.filter(x=>x.t===w.t&&x!==w&&x[field]!==w[field])),other=shuffle(W.filter(x=>x.t!==w.t&&x[field]!==w[field]));
  const out=[];for(const x of [...same,...other]){if(!out.includes(x[field]))out.push(x[field]);if(out.length===3)break}return shuffle([w[field],...out])}
const KIND={intro:"Новое слово",mc_pl:"Выбери перевод",mc_ru:"Выбери польское слово",cloze:"Вставь слово в предложение",type:"Напиши по-польски",listen:"Послушай и напиши"};
VIEWS.session=el=>{
  if(sess.empty){el.innerHTML=`<section class="panel center"><h1>Нечего повторять</h1><p class="muted">Все слова ждут своей даты повторения. Загляни завтра или сыграй в «Пары».</p><div class="row" style="justify-content:center"><button class="btn" id="sx">Ок</button><button class="btn primary" id="pairs">Пары</button></div></section>`;$("#sx").onclick=()=>{sess=null;render()};$("#pairs").onclick=()=>go("words/pairs");return}
  if(sess.pos>=sess.q.length)return sessionEnd(el);
  const it=sess.q[sess.pos],w=WI[it.id],fb=sess.fb;
  if(!it.opts&&(it.type==="mc_pl"||it.type==="mc_ru"))it.opts=distract(w,it.type==="mc_pl"?"ru":"pl");
  const bar=`<div class="sbar"><button class="x" id="sx" aria-label="Закончить">✕</button><div class="prog"><i style="width:${sess.pos/sess.q.length*100}%"></i></div><span class="score small">${sess.pos}/${sess.q.length}</span></div>`;
  let body="";
  if(it.type==="intro"){
    body=`<div class="intro pop"><div class="row between"><span class="label">${esc(w.t)}</span>${sayBtn(w.pl)}</div>
      <div class="big">${esc(w.pl)}</div><div class="tr">${esc(w.ru)}</div>
      <div><p class="ex">${esc(w.ex).replace(/\{(.+?)\}/,"<b>$1</b>")} ${sayBtn(w.ex,"sm")}</p><p class="exru">${esc(w.exru)}</p></div>
      ${w.hint?`<div class="hint">${esc(w.hint)}</div>`:""}
      <p class="xs muted">Произнеси слово и пример вслух — так оно запомнится быстрее.</p></div>
      <button class="btn primary wide" id="gotit">Запомнил</button>`;
  }else if(it.type==="mc_pl"||it.type==="mc_ru"){
    const prompt=it.type==="mc_pl"?w.pl:w.ru,right=it.type==="mc_pl"?w.ru:w.pl;
    body=`<div class="row between" style="flex-wrap:nowrap;align-items:flex-start"><div class="big">${esc(prompt)}</div>${it.type==="mc_pl"?sayBtn(w.pl):""}</div>
      <div class="opts">${it.opts.map((o,k)=>`<button class="opt ${fb?(o===right?"ok":k===sess.pick?"no":""):""}" data-mc="${k}" ${fb?"disabled":""}>${esc(o)}</button>`).join("")}</div>`;
  }else{
    let prompt="";
    if(it.type==="cloze")prompt=`<p class="ex" style="font-size:20px">${esc(w.ex).replace(/\{(.+?)\}/,`<span class="gap">${fb?esc(w.ans):"&nbsp;"}</span>`)}</p><p class="exru">${esc(w.exru)}</p><p class="small muted">Подсказка: <b>${esc(w.pl)}</b>${w.ans.toLowerCase()!==w.pl.toLowerCase()?" — поставь в нужную форму":""}</p>`;
    if(it.type==="type")prompt=`<div class="big">${esc(w.ru)}</div>`;
    if(it.type==="listen")prompt=`<button class="say bigsay" data-say="${esc(w.pl)}" aria-label="Слушать">${SPK}</button><div class="row" style="justify-content:center"><button class="chip" data-say="${esc(w.pl)}" data-rate=".55">Медленно</button></div>`;
    body=`<div data-keybox class="stage" style="padding:0">${prompt}
      <input type="text" id="ans" autocomplete="off" autocapitalize="off" spellcheck="false" lang="pl" placeholder="Напиши ответ…" value="${esc(sess.input)}" ${fb?"disabled":""}>
      ${KEYS(fb)}
      ${fb?"":`<div class="row between"><button class="btn" id="idk">Не знаю</button><button class="btn dark" id="chk">Проверить</button></div>`}</div>`;
  }
  el.innerHTML=bar+`<div class="stage"><div class="kind">${KIND[it.type]}${it.retry?" · ещё раз":""}</div>${body}</div>`;
  $("#sx").onclick=()=>{sess=null;render()};
  if(it.type==="intro"){if(!S.srs[w.id]){S.srs[w.id]={l:1,due:Date.now()};save()}if(!it.said){it.said=1;setTimeout(()=>say(w.pl),250)}$("#gotit").onclick=()=>{sess.pos++;render()}}
  if((it.type==="mc_pl"||it.type==="listen")&&!it.said&&!fb){it.said=1;setTimeout(()=>say(w.pl),250)}
  el.querySelectorAll("[data-mc]").forEach(b=>b.onclick=()=>{const k=+b.dataset.mc;sess.pick=k;answer(it.opts[k]===(it.type==="mc_pl"?w.ru:w.pl)?"ok":"no")});
  const inp=$("#ans");
  if(inp){if(!fb)setTimeout(()=>inp.focus(),50);inp.oninput=()=>sess.input=inp.value;
    const target=it.type==="cloze"?w.ans:w.pl;
    const c=$("#chk");if(c)c.onclick=()=>answer(check(inp.value,target));
    const k=$("#idk");if(k)k.onclick=()=>answer("no")}
  if(fb)showSheet(it,w);
};
function answer(res){
  const it=sess.q[sess.pos],w=WI[it.id],good=res!=="no";
  sess.fb=res;sess.n++;if(good)sess.ok++;
  const gain=res==="ok"?10:res==="accent"?8:0;sess.xp+=gain;addXP(gain,"w");
  const now=Date.now(),r=S.srs[w.id]||(S.srs[w.id]={l:1,due:now});
  if(!good){sess.failed.add(w.id);sess.q.splice(Math.min(sess.q.length,sess.pos+4),0,{type:it.type==="listen"||it.type==="type"?"cloze":it.type,id:w.id,isNew:it.isNew,retry:1,last:it.last})}
  if(!it.isNew&&!it.retry){if(good){r.l=Math.min(6,r.l+1);r.due=now+INT[r.l]*DAY}else{r.l=Math.max(1,r.l-2);r.due=now+DAY}}
  if(it.isNew&&it.last&&good){r.l=1;r.due=now+DAY}
  save();render();
}
function showSheet(it,w){
  const res=sess.fb,title=res==="ok"?"Верно!":res==="accent"?"Почти! Проверь польские буквы:":"Правильный ответ:";
  const right=it.type==="mc_pl"?w.ru:it.type==="cloze"?w.ans:w.pl;
  $("#sheet").innerHTML=`<div class="sheet ${res}"><div class="wrap">
    <div class="row between" style="flex-wrap:nowrap"><h2>${title}${res!=="ok"?` <span style="color:var(--ink)">${esc(right)}</span>`:""}</h2>${sayBtn(w.ex)}</div>
    <p class="ex">${esc(w.ex).replace(/\{(.+?)\}/,"<b>$1</b>")} <span class="exru">— ${esc(w.exru)}</span></p>
    ${res==="no"&&w.hint?`<p class="small" style="color:var(--ink)">${esc(w.hint)}</p>`:""}
    <button class="btn" id="next">Дальше</button></div></div>`;
  $("#next").onclick=nextItem;$("#next").focus({preventScroll:true});
}
function nextItem(){sess.pos++;sess.fb=null;sess.pick=null;sess.input="";render();window.scrollTo(0,0)}
document.addEventListener("keydown",e=>{if(e.key!=="Enter")return;
  if(sess&&sess.fb){e.preventDefault();return nextItem()}
  const a=document.activeElement;if(a&&a.matches("input[type=text]")){const c=a.closest("[data-keybox]")?.querySelector("[data-check]")||$("#chk");if(c){e.preventDefault();c.click()}}});
function sessionEnd(el){
  const acc=sess.n?Math.round(sess.ok/sess.n*100):100,tomorrow=W.filter(w=>S.srs[w.id]&&S.srs[w.id].due<=Date.now()+DAY).length;
  el.innerHTML=`<section class="panel center pop" style="padding:28px 18px">
    <div class="label">Сессия завершена</div><div class="result pass">+${sess.xp} XP</div>
    <div class="stats3" style="width:100%"><div class="stat"><b>${acc}%</b><span>точность</span></div><div class="stat"><b>${sess.newIds.length}</b><span>новых слов</span></div><div class="stat"><b>${tomorrow}</b><span>к повтору завтра</span></div></div>
    ${sess.failed.size?`<p class="small muted">Было трудно: ${[...sess.failed].map(esc).join(", ")}. Эти слова вернутся завтра.</p>`:`<p class="small muted">Без ошибок. Интервалы повторения выросли.</p>`}
    <div class="row" style="justify-content:center"><button class="btn" id="home">На главную</button><button class="btn primary" id="more">Ещё сессию</button></div></section>`;
  $("#home").onclick=()=>{sess=null;go("home")};$("#more").onclick=()=>startSession(S.deck);
}
/* pairs */
let pg=null;
function newPairs(){const seen=W.filter(w=>S.srs[w.id]),src=seen.length>=6?seen:W.filter(w=>!S.deck||w.t===S.deck),ws=pick(src,6);
  pg={L:shuffle(ws.map(w=>w.id)),Rr:shuffle(ws.map(w=>w.id)),sel:null,done:new Set(),err:null,t0:Date.now(),miss:0,end:null}}
function renderPairs(el){
  if(!pg)newPairs();
  if(pg.end){el.innerHTML=`<section class="panel center pop"><div class="label">Все пары найдены</div><div class="result pass">${(pg.end/1000).toFixed(1)} с</div><p class="small muted">Ошибок: ${pg.miss}${S.best?` · рекорд ${(S.best/1000).toFixed(1)} с`:""}</p><div class="row" style="justify-content:center"><button class="btn" data-route="words">Назад</button><button class="btn primary" id="again">Ещё раз</button></div></section>`;$("#again").onclick=()=>{pg=null;render()};return}
  const cell=(side,id)=>{const w=WI[id],k=side+"|"+id;return `<button class="pc ${pg.done.has(id)?"done":""} ${pg.sel===k?"sel":""} ${pg.err===k?"err":""}" data-pc="${esc(k)}">${esc(side==="L"?w.pl:w.ru)}</button>`};
  el.innerHTML=`<section class="panel"><div class="row between"><button class="btn" data-route="words">← Слова</button><span class="score small">${pg.done.size}/6 · ошибок ${pg.miss}</span></div>
    <p class="small muted">Соедини польское слово с переводом как можно быстрее.</p>
    <div class="pairs"><div class="col">${pg.L.map(id=>cell("L",id)).join("")}</div><div class="col">${pg.Rr.map(id=>cell("R",id)).join("")}</div></div></section>`;
  el.querySelectorAll("[data-pc]").forEach(b=>b.onclick=()=>{const k=b.dataset.pc,[side,id]=k.split("|");if(side==="L")say(WI[id].pl,1);
    if(!pg.sel||pg.sel[0]===side){pg.sel=k;pg.err=null;return render()}
    const other=pg.sel.split("|")[1];
    if(other===id){pg.done.add(id);pg.sel=null;addXP(2);if(pg.done.size===6){pg.end=Date.now()-pg.t0;if(!S.best||pg.end<S.best)S.best=pg.end;addXP(15);save()}}
    else{pg.miss++;pg.err=k;pg.sel=null;setTimeout(()=>{if(pg&&R.a==="pairs"){pg.err=null;render()}},450)}
    render()});
}
VIEWS.words=el=>{
  if(R.a==="pairs")return renderPairs(el);
  if(R.a&&DECKS.includes(R.a))S.deck=R.a;
  const pool=W.filter(w=>!S.deck||w.t===S.deck);
  const nNew=pool.filter(w=>!S.srs[w.id]).length,nLearn=pool.filter(w=>S.srs[w.id]&&lvl(w.id)<4).length,nDone=pool.length-nNew-nLearn;
  el.innerHTML=`
  <button class="cta" id="start"><div><b>Начать сессию</b><span>${dueWords().length} к повторению · ${Math.min(S.newPer,nNew)} новых${S.deck?" из «"+esc(S.deck)+"»":""}</span></div><span class="arr">→</span></button>
  ${(!ttsOK||ttsFailed)?ttsNoteHTML():""}
  <section class="panel">
    <div class="chips">${["Все",...DECKS].map(t=>`<button class="chip" data-deck="${t}" aria-pressed="${(S.deck||"Все")===t}">${t}</button>`).join("")}</div>
    <div class="stats3"><div class="stat"><b>${nNew}</b><span>новые</span></div><div class="stat"><b>${nLearn}</b><span>учатся</span></div><div class="stat"><b>${nDone}</b><span>выучены</span></div></div>
    <div class="row"><button class="btn ghost" data-route="words/pairs">Игра «Пары»</button></div>
  </section>
  <section class="panel"><h2>Как это работает</h2>
    <ul class="clean small"><li><b>Знакомство в контексте:</b> слово сразу в живом предложении, с озвучкой и подсказкой.</li>
    <li><b>От лёгкого к трудному:</b> узнать → выбрать → вставить в предложение в нужной форме → написать по памяти и на слух.</li>
    <li><b>Интервальное повторение:</b> знаешь — слово вернётся через 1, 2, 4, 7, 12, 20 дней. Ошибся — завтра.</li>
    <li><b>Ложные друзья:</b> похожие на русские слова с другим значением.</li></ul></section>
  <section class="panel"><h2>Словарь${S.deck?": "+esc(S.deck):""} · ${pool.length}</h2><div class="wlist">${pool.map(w=>{const l=lvl(w.id);return `<button class="wrow" data-say="${esc(w.pl)}"><span class="pl">${esc(w.pl)}</span><span class="ru">${esc(w.ru)}</span><span class="lv" aria-label="Уровень ${l} из 6">${[1,2,3,4,5,6].map(i=>`<i class="${S.srs[w.id]&&l>=i?"on":""}"></i>`).join("")}</span></button>`}).join("")}</div></section>`;
  $("#start").onclick=()=>startSession(S.deck);
  el.querySelectorAll("[data-deck]").forEach(b=>b.onclick=()=>{S.deck=b.dataset.deck==="Все"?null:b.dataset.deck;save();R.a=null;render()});
};

/* ============ GRAMMAR ============ */
const GMODES=[["mc","Выбор"],["forms","Формы"],["order","Порядок слов"],["errors","Найди ошибку"],["cheat","Шпаргалка"]];
const CASES=[["Mianownik","kto? co?","подлежащее; после «to», «jako»","To jest Anna. Pracuję jako kelner."],
["Dopełniacz","kogo? czego?","отрицание; szukać, bać się, potrzebować, uczyć się; do, od, z, bez, obok, dla, u; после 5+, dużo, kilo","Nie mam czasu. Idę do sklepu."],
["Celownik","komu? czemu?","dać, pomagać, dziękować, podobać się, pożyczyć; dzięki","Pomagam mamie."],
["Biernik","kogo? co?","mieć, lubić, znać, widzieć, kupić; na/w (куда), przez, za (за что)","Mam psa. Idę na pocztę."],
["Narzędnik","kim? czym?","być, zostać, interesować się; транспорт; z (с кем), przed, za, nad, pod, między (где)","Jestem lekarzem. Jadę tramwajem."],
["Miejscownik","o kim? o czym?","только с предлогами: w, na (где), o, przy, po","Mieszkam w Poznaniu."],
["Wołacz","—","обращение","Panie Tomaszu! Pani Anno!"]];
let gs={order:[]},fs=null,os=null,es=null;
function gramPool(f){if(f==="Ошибки")return S.miss.filter(i=>GRAM[i]);return GRAM.map((_,i)=>i).filter(i=>!f||GRAM[i][0]===f)}
VIEWS.gram=el=>{
  const mode=R.a||"mc";
  el.innerHTML=seg(GMODES,mode,"gram")+`<div id="gsub" style="display:flex;flex-direction:column;gap:14px"></div>`;
  G[mode]($("#gsub"));
};
const G={};
G.mc=el=>{
  const f=(!R.b||R.b==="Все")?null:R.b,pool=gramPool(f);
  if(gs.key!==f||!gs.order.length)gs={order:shuffle(pool),pos:0,ans:null,ok:0,n:0,key:f};
  const chips=`<div class="chips">${["Все",...GTAGS,"Ошибки"].map(t=>`<button class="chip" data-route="gram/mc/${t}" aria-pressed="${(f||"Все")===t}">${t}${t==="Ошибки"?` · ${S.miss.length}`:""}</button>`).join("")}</div>`;
  if(!pool.length){el.innerHTML=`<section class="panel">${chips}<p class="muted">Ошибок нет. Неверные ответы из упражнений и экзаменов собираются здесь.</p></section>`;return}
  const qi=gs.order[gs.pos%gs.order.length],g=GRAM[qi];
  el.innerHTML=`<section class="panel">${chips}
    <div class="row between"><span class="label">${esc(g[0])} · ${gs.pos%gs.order.length+1}/${gs.order.length}</span><span class="score">${gs.ok}/${gs.n}</span></div>
    <p class="q">${esc(g[1]).replace("___","<mark>___</mark>")}</p>
    <div class="opts">${g[2].map((o,k)=>`<button class="opt ${gs.ans!==null?(k===g[3]?"ok":k===gs.ans?"no":""):""}" data-o="${k}" ${gs.ans!==null?"disabled":""}>${esc(o)}</button>`).join("")}</div>
    ${gs.ans!==null?`<p class="explain">${esc(g[4])}</p><button class="btn primary wide" id="gnext">Дальше</button>`:""}</section>`;
  if(!gs.shuf||gs.shuf!==qi){gs.shuf=qi}
  el.querySelectorAll("[data-o]").forEach(b=>b.onclick=()=>{const k=+b.dataset.o;gs.ans=k;gs.n++;
    if(k===g[3]){gs.ok++;addXP(5,"g");if(f==="Ошибки")S.miss=S.miss.filter(x=>x!==qi)}else{addXP(0,"g");if(!S.miss.includes(qi))S.miss.push(qi)}save();render()});
  const nb=$("#gnext");if(nb)nb.onclick=()=>{gs.pos++;gs.ans=null;if(f==="Ошибки")gs.order=[];render()};
};
G.forms=el=>{
  if(!fs)fs={order:shuffle(FORMS.map((_,i)=>i)),pos:0,res:null,val:"",ok:0,n:0};
  const f=FORMS[fs.order[fs.pos%FORMS.length]];
  el.innerHTML=`<section class="panel" data-keybox>
    <div class="row between"><span class="label">Поставь слово в нужную форму</span><span class="score">${fs.ok}/${fs.n}</span></div>
    <p class="q">${esc(f[0]).replace("___",`<mark>${fs.res?esc(f[2].split("|")[0]):"___"}</mark>`)}</p>
    <p class="small muted">Слово: <b>${esc(f[1])}</b></p>
    <input type="text" id="fin" autocomplete="off" autocapitalize="off" spellcheck="false" lang="pl" value="${esc(fs.val)}" ${fs.res?"disabled":""} placeholder="Форма слова…">
    ${KEYS(fs.res)}
    ${fs.res?`<p class="explain ${fs.res}">${fs.res==="ok"?"Верно. ":fs.res==="accent"?"Почти — проверь буквы: ":"Правильно: <b>"+esc(f[2].split("|")[0])+"</b>. "}${esc(f[3])}</p><button class="btn primary wide" id="fnext">Дальше</button>`
      :`<div class="row between"><button class="btn" id="fidk">Не знаю</button><button class="btn dark" id="fchk" data-check>Проверить</button></div>`}</section>`;
  const inp=$("#fin");inp.oninput=()=>fs.val=inp.value;if(!fs.res)setTimeout(()=>inp.focus(),30);
  const grade=r=>{fs.res=r;fs.n++;if(r!=="no"){fs.ok++;addXP(6,"g")}else addXP(0,"g");render()};
  const c=$("#fchk");if(c)c.onclick=()=>grade(check(inp.value,f[2]));
  const k=$("#fidk");if(k)k.onclick=()=>grade("no");
  const n=$("#fnext");if(n){n.onclick=()=>{fs.pos++;fs.res=null;fs.val="";render()};n.focus({preventScroll:true})}
};
G.order=el=>{
  const mk=(i,prev)=>{const order=prev?prev.order:shuffle(ORDER.map((_,k)=>k)),o=ORDER[order[i%ORDER.length]];
    return{order,i,o,tiles:shuffle(o[0].replace(/[.?!]$/,"").split(" ").map(w=>({w}))),built:[],done:null,ok:prev?prev.ok:0,n:prev?prev.n:0}};
  if(!os)os=mk(0);
  const o=os.o,punct=o[0].slice(-1);
  const built=os.built.map(k=>os.tiles[k].w).join(" ");
  el.innerHTML=`<section class="panel">
    <div class="row between"><span class="label">Собери предложение</span><span class="score">${os.ok}/${os.n}</span></div>
    <p class="exru">${esc(o[2])}</p>
    <div class="built">${os.built.map((k,j)=>`<button class="tile" data-un="${j}" ${os.done?"disabled":""}>${esc(os.tiles[k].w)}</button>`).join("")||`<span class="muted small">Нажимай на слова ниже</span>`}<span class="muted">${os.built.length===os.tiles.length?esc(punct):""}</span></div>
    <div class="pool">${os.tiles.map((t,k)=>`<button class="tile ${os.built.includes(k)?"used":""}" data-tk="${k}" ${os.done||os.built.includes(k)?"disabled":""}>${esc(t.w)}</button>`).join("")}</div>
    ${os.done?`<p class="explain">${os.done==="ok"?"Верно!":"Правильно: <b>"+esc(o[0])+"</b>"}${o[1].length?` <span class="muted small">Тоже правильно: ${o[1].map(esc).join(" / ")}</span>`:""}</p>${sayBtn(o[0])}<button class="btn primary wide" id="onext">Дальше</button>`
      :`<div class="row between"><button class="btn" id="oclr">Сбросить</button><button class="btn dark" id="ochk" ${os.built.length<os.tiles.length?"disabled":""}>Проверить</button></div>`}</section>`;
  el.querySelectorAll("[data-tk]").forEach(b=>b.onclick=()=>{os.built.push(+b.dataset.tk);render()});
  el.querySelectorAll("[data-un]").forEach(b=>b.onclick=()=>{os.built.splice(+b.dataset.un,1);render()});
  const c=$("#ochk");if(c)c.onclick=()=>{const s=low(built),ok=[o[0],...o[1]].some(x=>low(x)===s);os.done=ok?"ok":"no";os.n++;if(ok){os.ok++;addXP(8,"g")}else addXP(0,"g");if(ok)say(o[0]);render()};
  const cl=$("#oclr");if(cl)cl.onclick=()=>{os.built=[];render()};
  const n=$("#onext");if(n)n.onclick=()=>{os=mk(os.i+1,os);render()};
};
G.errors=el=>{
  if(!es)es={order:shuffle(ERRORS.map((_,i)=>i)),pos:0,pick:null,ok:0,n:0};
  const e=ERRORS[es.order[es.pos%ERRORS.length]],words=e[0].split(" ");
  el.innerHTML=`<section class="panel">
    <div class="row between"><span class="label">Нажми на слово с ошибкой</span><span class="score">${es.ok}/${es.n}</span></div>
    <div class="errline">${words.map((w,k)=>`<button class="tile ${es.pick!==null?(k===e[1]?"bad":k===es.pick?"miss":""):""}" data-ew="${k}" ${es.pick!==null?"disabled":""}>${esc(w)}</button>`).join("")}</div>
    ${es.pick!==null?`<p class="explain">${es.pick===e[1]?"Нашёл! ":"Ошибка в другом слове. "}Правильно: <b>${esc(e[2])}</b>. ${esc(e[3])}</p><button class="btn primary wide" id="enext">Дальше</button>`:""}</section>`;
  el.querySelectorAll("[data-ew]").forEach(b=>b.onclick=()=>{es.pick=+b.dataset.ew;es.n++;if(es.pick===e[1]){es.ok++;addXP(6,"g")}else addXP(0,"g");render()});
  const n=$("#enext");if(n)n.onclick=()=>{es.pos++;es.pick=null;render()};
};
G.cheat=el=>{
  el.innerHTML=`<section class="panel"><h2>Падежи</h2><div class="tbl"><table><tr><th>Падеж</th><th>Вопрос</th><th>Когда</th><th>Пример</th></tr>${CASES.map(c=>`<tr><td>${c[0]}</td><td>${c[1]}</td><td>${esc(c[2])}</td><td>${esc(c[3])}</td></tr>`).join("")}</table></div></section>
  <section class="panel"><h2>Вид глагола</h2><ul class="clean small"><li><b>Несовершенный</b> (robić, pisać): процесс, повтор, «как долго». Codziennie piszę maile.</li><li><b>Совершенный</b> (zrobić, napisać): результат, один раз. Форма настоящего = будущее: Jutro napiszę.</li><li>Маркеры: codziennie, często, cały dzień → несов.; już, nagle, w końcu → сов.</li><li>Фон + событие: Kiedy gotowałam (фон), zadzwonił telefon (событие).</li></ul></section>
  <section class="panel"><h2>Глаголы движения</h2><ul class="clean small"><li><b>iść / jechać</b> — сейчас, в одну сторону: Teraz idę do domu.</li><li><b>chodzić / jeździć</b> — регулярно или туда-обратно: Co tydzień jeżdżę do Berlina.</li><li><b>pójść / pojechać</b> — разово в будущем или прошлом: Wczoraj pojechałem nad morze.</li></ul></section>
  <section class="panel"><h2>Числительные</h2><ul class="clean small"><li><b>1</b>: jeden kot, jedna kobieta, jedno okno.</li><li><b>2–4</b> + им. п. мн. ч.: dwa koty, dwie siostry, trzy okna. Мужчины: dwóch braci.</li><li><b>5+</b> + род. п. мн. ч.: pięć kotów, sześć kobiet, dziesięciu mężczyzn.</li><li>Даты: dwudziestego marca (род. п.). Время: o ósmej, o wpół do dziewiątej.</li></ul></section>
  <section class="panel"><h2>Предлоги времени</h2><ul class="clean small"><li><b>o</b> + час: o piątej. <b>w</b> + день/месяц: w poniedziałek, w maju.</li><li><b>od</b> — с какого момента: od roku. <b>przez</b> — в течение: przez rok.</li><li><b>za</b> — через: za tydzień. <b>temu</b> — назад: tydzień temu.</li></ul></section>
  <section class="panel"><h2>Tryb przypuszczający</h2><ul class="clean small"><li>форма прошедшего + bym/byś/by/byśmy/byście/by: zrobiłbym, zrobiłabyś, zrobiliby.</li><li>Gdybym miał czas, pojechałbym… (если бы…, то бы…)</li><li>Вежливо: Chciałbym…, Czy mógłby Pan…?</li></ul></section>`;
};

/* ============ PRACTICE ============ */
const PTABS=[["read","Чтение"],["audio","Аудирование"],["dict","Диктант"],["shadow","Повтор вслух"],["write","Письмо"],["speak","Говорение"]];
let rs={},as={},ds={i:0,order:shuffle(DICT.map((_,i)=>i))},sh={i:0,order:shuffle(W.map(w=>w.id)),reps:0},tm={left:0,id:null,phase:""};
const norm=s=>s.toLowerCase().replace(/[.,!?;:„”"–—-]/g," ").split(/\s+/).filter(Boolean);
VIEWS.practice=el=>{const sub=R.a||"read",n=R.b!=null?+R.b:null;
  el.innerHTML=seg(PTABS,sub,"practice")+`<div id="psub" style="display:flex;flex-direction:column;gap:14px"></div>`;P[sub]($("#psub"),n)};
const P={};
function quizHTML(qs,ans,prefix){return qs.map((q,k)=>`<section class="panel"><p class="q" style="font-size:16px">${k+1}. ${esc(q[0])}</p><div class="opts">${q[1].map((o,j)=>`<button class="opt ${ans[k]!==undefined?(j===q[2]?"ok":j===ans[k]?"no":""):""}" data-${prefix}="${k}-${j}" ${ans[k]!==undefined?"disabled":""}>${esc(o)}</button>`).join("")}</div></section>`).join("")}
P.read=(el,n)=>{
  const i=n??0,r=READ[i];rs[i]=rs[i]||{};const a=rs[i],right=r.q.filter((q,k)=>a[k]===q[2]).length;
  el.innerHTML=`<section class="panel"><div class="chips">${READ.map((x,k)=>`<button class="chip" data-route="practice/read/${k}" aria-pressed="${i===k}">${k+1}. ${esc(x.t)}</button>`).join("")}</div>
    <div class="row between" style="flex-wrap:nowrap"><h2>${esc(r.t)}</h2>${sayBtn(r.x)}</div><div class="reading">${esc(r.x)}</div>
    <p class="xs muted">Сначала прочитай вопросы, потом текст — так ищешь нужное, а не переводишь всё подряд.</p></section>
    ${quizHTML(r.q,a,"rq")}
    ${Object.keys(a).length===r.q.length?`<section class="panel"><p class="score">Результат: ${right} из ${r.q.length}</p><div class="row"><button class="btn" id="rreset">Заново</button>${i<READ.length-1?`<button class="btn primary" data-route="practice/read/${i+1}">Следующий текст</button>`:""}</div></section>`:""}`;
  el.querySelectorAll("[data-rq]").forEach(b=>b.onclick=()=>{const[k,j]=b.dataset.rq.split("-").map(Number);a[k]=j;if(j===r.q[k][2])addXP(5);render()});
  const rr=$("#rreset");if(rr)rr.onclick=()=>{rs[i]={};render()};
};
P.audio=(el,n)=>{
  const i=n??0,L=LISTEN[i];as[i]=as[i]||{a:{},show:false,plays:0};const st=as[i],right=L.q.filter((q,k)=>st.a[k]===q[2]).length,all=Object.keys(st.a).length===L.q.length;
  el.innerHTML=`<section class="panel"><div class="chips">${LISTEN.map((x,k)=>`<button class="chip" data-route="practice/audio/${k}" aria-pressed="${i===k}">${k+1}. ${esc(x.t)}</button>`).join("")}</div>
    <h2>${esc(L.t)}</h2>
    <p class="small muted">Как на экзамене: прочитай вопросы, послушай запись дважды, потом отвечай. Текст можно открыть после ответов.</p>
    ${ttsOK?`<div class="row"><button class="btn primary" id="play">▶ Слушать${st.plays?` (${st.plays})`:""}</button><button class="btn" id="slow">Медленно</button></div>`:ttsNoteHTML()}
    ${st.show||all?`<div class="reading small">${L.x.map(l=>"— "+esc(l)).join("<br>")}</div>`:`<button class="btn ghost" id="show">Показать текст</button>`}</section>
    ${quizHTML(L.q,st.a,"aq")}
    ${all?`<section class="panel"><p class="score">Результат: ${right} из ${L.q.length}</p>${i<LISTEN.length-1?`<button class="btn primary" data-route="practice/audio/${i+1}">Следующая запись</button>`:""}</section>`:""}
    <section class="panel"><h2>Аудирование каждый день</h2><ul class="clean small"><li>15–20 минут польского радио или подкаста: Polskie Radio, «Real Polish».</li><li>Один фрагмент трижды: общий смысл → детали (числа, даты, места) → с текстом.</li><li>На экзамене ловят на деталях: время, цены, отрицания.</li></ul></section>`;
  const p=$("#play");if(p)p.onclick=()=>{st.plays++;p.textContent=`▶ Слушать (${st.plays})`;sayAll(L.x,.92)};
  const s=$("#slow");if(s)s.onclick=()=>sayAll(L.x,.7);
  const sh2=$("#show");if(sh2)sh2.onclick=()=>{st.show=true;render()};
  el.querySelectorAll("[data-aq]").forEach(b=>b.onclick=()=>{const[k,j]=b.dataset.aq.split("-").map(Number);st.a[k]=j;addXP(j===L.q[k][2]?5:0,"d");render()});
};
P.dict=el=>{
  if(!ttsOK){el.innerHTML=`<section class="panel">${ttsNoteHTML()}</section>`;return}
  const t=DICT[ds.order[ds.i%DICT.length]];
  el.innerHTML=`<section class="panel" data-keybox><h2>Диктант</h2>
    <div class="row"><button class="btn primary" data-say="${esc(t)}">▶ Слушать</button><button class="btn" data-say="${esc(t)}" data-rate=".6">Медленно</button><span class="small muted">${ds.i%DICT.length+1} / ${DICT.length}</span></div>
    <input type="text" id="dictin" placeholder="Пиши по-польски…" autocomplete="off" spellcheck="false" lang="pl">${KEYS()}
    <div class="row between"><button class="btn" id="dnext">Следующая</button><button class="btn dark" id="dchk" data-check>Проверить</button></div><div id="dres"></div></section>`;
  const inp=$("#dictin");
  $("#dchk").onclick=()=>{const u=norm(inp.value),c=norm(t);let ok=0;
    const html=c.map((w,i)=>{if(u[i]===w){ok++;return `<span>${esc(w)}</span>`}return(u[i]?`<span class="w">${esc(u[i])}</span> `:"")+`<span class="r">${esc(w)}</span>`}).join(" ");
    if(!$("#dchk").dataset.done){$("#dchk").dataset.done=1;addXP(Math.round(ok/c.length*10),"d")}
    $("#dres").innerHTML=`<p class="score">${ok} из ${c.length} слов</p><p class="diff">${html}</p>`};
  $("#dnext").onclick=()=>{ds.i++;render()};
};
P.shadow=el=>{
  const w=WI[sh.order[sh.i%sh.order.length]],s=w.ex.replace(/[{}]/g,"");
  el.innerHTML=`<section class="panel"><h2>Повтор вслух</h2><p class="small muted">Shadowing: слушаешь фразу и сразу повторяешь вслух, копируя ритм и интонацию. Три повтора — и фраза «ложится» в рот. Лучшая подготовка к устной части.</p></section>
    <section class="panel center pop"><p class="big" style="font-size:22px">${esc(s)}</p><p class="exru">${esc(w.exru)}</p>
    ${ttsOK?`<div class="row" style="justify-content:center"><button class="btn primary" data-say="${esc(s)}">▶ Слушать</button><button class="btn" data-say="${esc(s)}" data-rate=".6">Медленно</button></div>`:""}
    <div class="row" style="justify-content:center;gap:6px">${[0,1,2].map(i=>`<span style="width:28px;height:8px;border-radius:9px;background:${sh.reps>i?"var(--good)":"var(--line)"}"></span>`).join("")}</div>
    <button class="btn dark wide" id="rep">${sh.reps<3?"Повторил вслух ("+(sh.reps+1)+"/3)":"Следующая фраза →"}</button></section>`;
  $("#rep").onclick=()=>{if(sh.reps<3){sh.reps++;if(sh.reps===3)addXP(5,"sh")}else{sh.reps=0;sh.i++;say(WI[sh.order[sh.i%sh.order.length]].ex)}render()};
};
const LINKERS=/\b(ponieważ|dlatego|jednak|ale|bo|więc|chociaż|natomiast|poza tym|przede wszystkim|podsumowując|z jednej strony|moim zdaniem)\b/i;
P.write=(el,n)=>{
  const i=n??(P.wi||0);P.wi=i;const w=WRITE[i];
  el.innerHTML=`<section class="panel"><label class="label" for="wsel">Задание</label>
    <select id="wsel">${WRITE.map((x,k)=>`<option value="${k}" ${i===k?"selected":""}>${esc(x.t)}</option>`).join("")}</select>
    <p class="q" style="font-size:17px">${esc(w.task)}</p>
    <div><div class="label" style="margin-bottom:4px">Обязательно упомяни</div>${w.pts.map((p,k)=>`<div class="task" style="padding:6px 0"><input type="checkbox" id="wp${k}"><label for="wp${k}">${esc(p)}</label></div>`).join("")}</div></section>
    <section class="panel" data-keybox><div class="chips">${PHR[w.kind].map(p=>`<button class="chip" data-ph="${esc(p)}">${esc(p)}</button>`).join("")}</div>
    <textarea id="wtext" placeholder="Pisz tutaj…" spellcheck="true" lang="pl">${esc(S.draft)}</textarea>${KEYS()}
    <div class="row between"><span class="score" id="wc"></span><span class="small" id="wlink"></span></div>
    <div class="row between"><button class="btn" id="wclear">Очистить</button><button class="btn ghost" id="wmodel">Показать образец</button></div>
    <div id="wm"></div>
    <p class="small muted">Для тренировки — 100–150 слов. Сначала напиши сам, потом сравни с образцом: какие фразы можно взять себе.</p></section>`;
  const ta=$("#wtext"),wc=()=>{const k=ta.value.trim().split(/\s+/).filter(Boolean).length;$("#wc").textContent=k+" слов";$("#wlink").textContent=LINKERS.test(ta.value)?"✓ есть связки":"добавь связки: bo, dlatego, jednak"};wc();
  ta.oninput=()=>{S.draft=ta.value;save();wc()};
  $("#wsel").onchange=e=>go("practice/write/"+e.target.value);
  el.querySelectorAll("[data-ph]").forEach(b=>b.onclick=()=>{const p=b.dataset.ph+" ",s=ta.selectionStart??ta.value.length;ta.value=ta.value.slice(0,s)+p+ta.value.slice(s);ta.focus();ta.selectionStart=ta.selectionEnd=s+p.length;S.draft=ta.value;save();wc()});
  $("#wclear").onclick=e=>{const b=e.target;if(b.dataset.sure){ta.value="";S.draft="";save();wc();b.textContent="Очистить";delete b.dataset.sure}else{b.dataset.sure=1;b.textContent="Точно очистить?"}};
  $("#wmodel").onclick=()=>{$("#wm").innerHTML=`<div class="reading small" style="white-space:pre-line">${esc(w.model)}</div>`;addXP(5)};
};
P.speak=(el,n)=>{
  if(n!=null)P.si=n;const i=P.si||0,s=SPEAK[i];
  el.innerHTML=`<section class="panel"><div class="row between"><span class="label">${esc(s[1])} · ${i+1}/${SPEAK.length}</span><button class="btn ghost" id="srand">Другая тема</button></div>
    <div class="row between" style="flex-wrap:nowrap;align-items:flex-start"><p class="q">${esc(s[0])}</p>${sayBtn(s[0])}</div></section>
    <section class="panel center"><div class="label" id="tph">${tm.phase||"Таймер"}</div><div class="timer" id="tt">${fmt(tm.left||60)}</div>
    <div class="row" style="justify-content:center"><button class="btn" id="tprep">Подготовка 1:00</button><button class="btn primary" id="tans">Ответ 2:00</button><button class="btn" id="tstop">Стоп</button></div>
    <p class="small muted">Говори вслух, даже если один. Цель — 2 минуты без длинных пауз. Запиши себя на диктофон и послушай.</p></section>
    <section class="panel"><h2>Фразы, которые спасают</h2><div class="row">${SPHR.map(p=>`<span class="chip">${esc(p)}</span>`).join("")}</div></section>`;
  $("#srand").onclick=()=>{let k;do{k=Math.random()*SPEAK.length|0}while(k===i);P.si=k;render()};
  $("#tprep").onclick=()=>startT(60,"Подготовка");$("#tans").onclick=()=>startT(120,"Ответ");
  $("#tstop").onclick=()=>{clearInterval(tm.id);tm.phase="Остановлено";upT()};
};
const fmt=s=>`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
function upT(){const t=$("#tt"),p=$("#tph");if(t)t.textContent=fmt(tm.left);if(p)p.textContent=tm.phase}
function startT(sec,ph){clearInterval(tm.id);tm.left=sec;tm.phase=ph;upT();tm.id=setInterval(()=>{tm.left--;if(tm.left<=0){clearInterval(tm.id);tm.left=0;tm.phase=ph+" — время вышло";if(ph==="Ответ")addXP(20,"s")}upT()},1000)}

/* ============ EXAM ============ */
const TTABS=[["mock","Пробный экзамен"],["quick","Быстрый тест"],["info","Об экзамене"]];
let ts=null,mx=null;
VIEWS.test=el=>{const sub=R.a||"mock";el.innerHTML=seg(TTABS,sub,"test")+`<div id="tsub" style="display:flex;flex-direction:column;gap:14px"></div>`;T[sub]($("#tsub"))};
const T={};
T.info=sub=>{sub.innerHTML=`
  <section class="panel"><h1>Государственный экзамен B1</h1><p>Две части — письменная и устная. Сдаёшь, если набрал <b>не меньше 50% в каждой части</b>, а не в сумме.</p></section>
  <section class="panel"><h2>Письменная часть · до 190 минут</h2><div class="parts">
    <div class="part"><b>Rozumienie ze słuchu</b><span class="small muted">Аудирование, вопросы на детали</span></div>
    <div class="part"><b>Poprawność gramatyczna</b><span class="small muted">Падежи, формы глаголов, вид</span></div>
    <div class="part"><b>Rozumienie tekstów pisanych</b><span class="small muted">Объявления, письма, статьи</span></div>
    <div class="part"><b>Pisanie</b><span class="small muted">E-mail, письмо, текст-мнение</span></div></div></section>
  <section class="panel"><h2>Устная часть · до 15 минут</h2><p>Тянешь один из трёх наборов (2–3 задания по тексту или картинке) и выполняешь их перед комиссией.</p></section>
  <section class="panel"><h2>Советы</h2><ul class="clean"><li>Лучше 30–40 минут каждый день, чем 3 часа раз в неделю.</li><li>Самые частые ошибки на B1 — падежи после предлогов и вид глагола.</li><li>Пройди хотя бы один официальный образец теста целиком на время.</li><li>Накануне проверь документ, адрес и время начала.</li></ul>
  <p class="small">Образцы тестов и даты сессий: <a href="https://certyfikatpolski.pl" target="_blank" rel="noopener">certyfikatpolski.pl</a></p></section>`};
T.quick=sub=>{
  if(!ts){const g=pick(GRAM.map((_,i)=>i),12).map(i=>({kind:"g",i,q:GRAM[i][1],o:GRAM[i][2],a:GRAM[i][3],tag:GRAM[i][0]}));
    const v=pick(W,8).map(w=>{const o=distract(w,"ru");return{kind:"v",q:`Что значит «${w.pl}»?`,o,a:o.indexOf(w.ru),tag:"Słownictwo"}});ts={items:shuffle([...g,...v]),ans:{},done:false}}
  const n=ts.items.length,answered=Object.keys(ts.ans).length;
  if(ts.done){const right=ts.items.filter((it,i)=>ts.ans[i]===it.a).length,pct=Math.round(right/n*100);
    sub.innerHTML=`<section class="panel"><div class="label">Результат</div><div class="result ${pct>=50?"pass":"fail"}">${pct}%</div><p>${right} из ${n}.</p>
      <div class="row"><button class="btn primary" id="tnew">Новый тест</button><button class="btn" data-route="gram/mc/Ошибки">Разобрать ошибки</button></div></section>
      ${ts.items.map((it,i)=>ts.ans[i]===it.a?"":`<section class="panel"><p class="xs muted">${esc(it.tag)}</p><p>${esc(it.q)}</p><p class="small">Твой ответ: <span style="color:var(--bad)">${esc(it.o[ts.ans[i]]??"—")}</span> · Верно: <b style="color:var(--good)">${esc(it.o[it.a])}</b></p>${it.kind==="g"?`<p class="explain">${esc(GRAM[it.i][4])}</p>`:""}</section>`).join("")}`;
    $("#tnew").onclick=()=>{ts=null;render()};return}
  sub.innerHTML=`<section class="panel"><div class="row between"><h2>20 вопросов</h2><span class="score">${answered}/${n}</span></div><p class="small muted">Грамматика и лексика. Ответы — в конце.</p></section>
    ${ts.items.map((it,i)=>`<section class="panel"><p class="xs muted">${i+1} · ${esc(it.tag)}</p><p class="q" style="font-size:16px">${esc(it.q).replace("___","<mark>___</mark>")}</p><div class="opts">${it.o.map((o,k)=>`<button class="opt ${ts.ans[i]===k?"pick":""}" data-t="${i}-${k}">${esc(o)}</button>`).join("")}</div></section>`).join("")}
    <section class="panel"><button class="btn primary wide" id="tfin" ${answered<n?"disabled":""}>Завершить тест</button></section>`;
  sub.querySelectorAll("[data-t]").forEach(b=>b.onclick=()=>{const[i,k]=b.dataset.t.split("-").map(Number);ts.ans[i]=k;const y=window.scrollY;render();window.scrollTo(0,y)});
  $("#tfin").onclick=()=>{ts.done=true;let ok=0;ts.items.forEach((it,i)=>{if(ts.ans[i]===it.a)ok++;else if(it.kind==="g"&&!S.miss.includes(it.i))S.miss.push(it.i)});addXP(ok*3);save();render();window.scrollTo(0,0)};
};
/* full mock exam by parts */
const MPARTS=["Słuchanie","Gramatyka","Czytanie","Pisanie"];
function newMock(){
  const li=pick(LISTEN.map((_,i)=>i),3),ri=pick(READ.map((_,i)=>i),2);
  mx={step:-1,
    listen:li.map(i=>({i,plays:0})),la:{},
    gram:pick(GRAM.map((_,i)=>i),14),ga:{},forms:pick(FORMS.map((_,i)=>i),6),fa:{},
    read:ri,ra:{},
    write:Math.random()*WRITE.length|0,text:"",checks:{},
    score:{},t0:Date.now(),wEnd:null}
}
function mockLQ(){const out=[];mx.listen.forEach((L,li)=>LISTEN[L.i].q.forEach((q,k)=>out.push({key:li+"-"+k,q})));return out}
function mockRQ(){const out=[];mx.read.forEach((r,ri)=>READ[r].q.forEach((q,k)=>out.push({key:ri+"-"+k,q})));return out}
T.mock=sub=>{
  if(!mx)newMock();
  const stepper=`<div class="steps">${MPARTS.map((p,i)=>`<span class="${i===mx.step?"cur":i<mx.step?"done":""}">${i+1}. ${p}</span>`).join("")}</div>`;
  if(mx.step===-1){
    sub.innerHTML=`<section class="panel"><h1>Пробный экзамен</h1><p>Четыре части, как в письменной части настоящего экзамена. В конце — процент по каждой части. Чтобы «сдать», нужно ≥50% в каждой.</p>
      <ul class="clean small"><li><b>Słuchanie</b> — 3 записи, 9 вопросов</li><li><b>Gramatyka</b> — 14 вопросов на выбор + 6 форм</li><li><b>Czytanie</b> — 2 текста</li><li><b>Pisanie</b> — 1 письмо, 30 минут, самопроверка по критериям</li></ul>
      <p class="small muted">Займёт около 60–70 минут. Отвечай без подсказок и шпаргалки.</p>
      <button class="btn primary wide" id="mstart">Начать</button></section>
      ${S.mocks.length?`<section class="panel"><h2>Прошлые попытки</h2>${S.mocks.slice(-6).reverse().map(m=>`<div class="row between small" style="border-top:1px solid var(--line);padding-top:8px"><span>${esc(m.date)}</span><span class="score">${MPARTS.map((p,i)=>`<span class="${m.parts[i]>=50?"pass":"fail"}">${m.parts[i]}%</span>`).join(" · ")}</span></div>`).join("")}</section>`:""}`;
    $("#mstart").onclick=()=>{mx.step=0;render();window.scrollTo(0,0)};return}
  if(mx.step===0){const qs=mockLQ();
    sub.innerHTML=stepper+mx.listen.map((L,li)=>{const D=LISTEN[L.i];return `<section class="panel"><div class="row between"><h2>Запись ${li+1}</h2>${ttsOK?`<button class="btn primary" data-play="${li}" ${L.plays>=2?"disabled":""}>▶ Слушать (${2-L.plays} из 2)</button>`:""}</div>
      ${!ttsOK?ttsNoteHTML():""}${D.q.map((q,k)=>{const key=li+"-"+k;return `<p class="q" style="font-size:16px">${esc(q[0])}</p><div class="opts">${q[1].map((o,j)=>`<button class="opt ${mx.la[key]===j?"pick":""}" data-ml="${key}-${j}">${esc(o)}</button>`).join("")}</div>`}).join("")}</section>`}).join("")+
      `<section class="panel"><button class="btn primary wide" id="mnext" ${Object.keys(mx.la).length<qs.length?"disabled":""}>Дальше: грамматика</button></section>`;
    sub.querySelectorAll("[data-play]").forEach(b=>b.onclick=()=>{const L=mx.listen[+b.dataset.play];if(L.plays>=2)return;L.plays++;sayAll(LISTEN[L.i].x,.92);b.textContent=`▶ Слушать (${2-L.plays} из 2)`;if(L.plays>=2)b.disabled=true});
    sub.querySelectorAll("[data-ml]").forEach(b=>b.onclick=()=>{const p=b.dataset.ml.split("-");mx.la[p[0]+"-"+p[1]]=+p[2];keepScroll()});
    $("#mnext").onclick=()=>{mx.score[0]=Math.round(qs.filter(x=>mx.la[x.key]===x.q[2]).length/qs.length*100);mx.step=1;render();window.scrollTo(0,0)};return}
  if(mx.step===1){const total=mx.gram.length+mx.forms.length,answered=Object.keys(mx.ga).length+Object.values(mx.fa).filter(v=>v.trim()).length;
    sub.innerHTML=stepper+mx.gram.map((gi,k)=>{const g=GRAM[gi];return `<section class="panel"><p class="xs muted">${k+1}</p><p class="q" style="font-size:16px">${esc(g[1]).replace("___","<mark>___</mark>")}</p><div class="opts">${g[2].map((o,j)=>`<button class="opt ${mx.ga[k]===j?"pick":""}" data-mg="${k}-${j}">${esc(o)}</button>`).join("")}</div></section>`}).join("")+
      `<section class="panel" data-keybox><h2>Поставь слова в нужную форму</h2>${mx.forms.map((fi,k)=>{const f=FORMS[fi];return `<div style="display:flex;flex-direction:column;gap:6px;border-top:1px solid var(--line);padding-top:10px"><p>${esc(f[0])} <span class="muted small">(${esc(f[1])})</span></p><input type="text" data-mf="${k}" value="${esc(mx.fa[k]||"")}" autocomplete="off" autocapitalize="off" spellcheck="false" lang="pl"></div>`}).join("")}${KEYS()}</section>
      <section class="panel"><button class="btn primary wide" id="mnext">Дальше: чтение</button><p class="xs muted">Отвечено ${answered} из ${total}</p></section>`;
    sub.querySelectorAll("[data-mg]").forEach(b=>b.onclick=()=>{const[k,j]=b.dataset.mg.split("-").map(Number);mx.ga[k]=j;keepScroll()});
    sub.querySelectorAll("[data-mf]").forEach(inp=>inp.oninput=()=>{mx.fa[inp.dataset.mf]=inp.value});
    $("#mnext").onclick=()=>{let ok=0;mx.gram.forEach((gi,k)=>{if(mx.ga[k]===GRAM[gi][3])ok++;else if(!S.miss.includes(gi))S.miss.push(gi)});mx.forms.forEach((fi,k)=>{if(check(mx.fa[k]||"",FORMS[fi][2])!=="no")ok++});
      mx.score[1]=Math.round(ok/total*100);save();mx.step=2;render();window.scrollTo(0,0)};return}
  if(mx.step===2){const qs=mockRQ();
    sub.innerHTML=stepper+mx.read.map((r,ri)=>{const D=READ[r];return `<section class="panel"><h2>${esc(D.t)}</h2><div class="reading">${esc(D.x)}</div>${D.q.map((q,k)=>{const key=ri+"-"+k;return `<p class="q" style="font-size:16px">${esc(q[0])}</p><div class="opts">${q[1].map((o,j)=>`<button class="opt ${mx.ra[key]===j?"pick":""}" data-mr="${key}-${j}">${esc(o)}</button>`).join("")}</div>`}).join("")}</section>`}).join("")+
      `<section class="panel"><button class="btn primary wide" id="mnext" ${Object.keys(mx.ra).length<qs.length?"disabled":""}>Дальше: письмо</button></section>`;
    sub.querySelectorAll("[data-mr]").forEach(b=>b.onclick=()=>{const p=b.dataset.mr.split("-");mx.ra[p[0]+"-"+p[1]]=+p[2];keepScroll()});
    $("#mnext").onclick=()=>{mx.score[2]=Math.round(qs.filter(x=>mx.ra[x.key]===x.q[2]).length/qs.length*100);mx.step=3;mx.wEnd=Date.now()+30*60e3;render();window.scrollTo(0,0)};return}
  if(mx.step===3){const w=WRITE[mx.write],words=mx.text.trim().split(/\s+/).filter(Boolean).length;
    sub.innerHTML=stepper+`<section class="panel"><div class="row between"><h2>${esc(w.t)}</h2><span class="score" id="wtimer"></span></div><p class="q" style="font-size:17px">${esc(w.task)}</p>
      <ul class="clean small">${w.pts.map(p=>`<li>${esc(p)}</li>`).join("")}</ul></section>
      <section class="panel" data-keybox><textarea id="mtext" lang="pl" placeholder="Pisz tutaj…">${esc(mx.text)}</textarea>${KEYS()}<span class="score" id="mwc">${words} слов</span></section>
      <section class="panel"><h2>Самопроверка</h2><p class="small muted">Честно отметь, что получилось. Каждый пункт — 1 балл.</p>
      ${[...w.pts.map(p=>"Раскрыт пункт: "+p),"Объём 100+ слов","Приветствие и прощание в нужном стиле","Есть связки (bo, dlatego, jednak…)","Нет грубых ошибок в падежах и временах"].map((c,k)=>`<div class="task" style="padding:6px 0"><input type="checkbox" id="mc${k}" data-mc="${k}" ${mx.checks[k]?"checked":""}><label for="mc${k}">${esc(c)}</label></div>`).join("")}
      <button class="btn primary wide" id="mnext">Завершить экзамен</button></section>`;
    const ta=$("#mtext");ta.oninput=()=>{mx.text=ta.value;$("#mwc").textContent=ta.value.trim().split(/\s+/).filter(Boolean).length+" слов"};
    sub.querySelectorAll("[data-mc]").forEach(c=>c.onchange=()=>{mx.checks[c.dataset.mc]=c.checked});
    const tick=()=>{const t=$("#wtimer");if(!t||!mx||mx.step!==3)return;const left=Math.max(0,Math.round((mx.wEnd-Date.now())/1000));t.textContent=left?fmt(left):"Время вышло";setTimeout(tick,1000)};tick();
    $("#mnext").onclick=()=>{const n=w.pts.length+4,ok=Object.values(mx.checks).filter(Boolean).length;mx.score[3]=Math.round(ok/n*100);mx.step=4;
      const parts=[0,1,2,3].map(i=>mx.score[i]||0),total=Math.round(parts.reduce((a,b)=>a+b,0)/4);
      S.mocks.push({date:ymd(),parts,total});addXP(50);save();render();window.scrollTo(0,0)};return}
  const parts=[0,1,2,3].map(i=>mx.score[i]||0),pass=parts.every(p=>p>=50),w=WRITE[mx.write];
  sub.innerHTML=`<section class="panel"><div class="label">Результат</div><div class="result ${pass?"pass":"fail"}">${pass?"Сдано":"Пока не сдано"}</div>
    <div class="mres">${MPARTS.map((p,i)=>`<div class="mrow"><span>${p}</span><div class="mbar"><i style="width:${parts[i]}%" class="${parts[i]>=50?"g":"b"}"></i><em></em></div><b class="${parts[i]>=50?"pass":"fail"}">${parts[i]}%</b></div>`).join("")}</div>
    <p class="small muted">Отметка на шкале — порог 50%. ${pass?"Все части выше порога. Так держать!":"Подтяни части ниже порога: план на завтра — именно они."}</p>
    <div class="row"><button class="btn primary" id="again">Новый экзамен</button><button class="btn" data-route="gram/mc/Ошибки">Ошибки грамматики</button></div></section>
    <section class="panel"><h2>Образец письма</h2><div class="reading small" style="white-space:pre-line">${esc(w.model)}</div></section>`;
  $("#again").onclick=()=>{newMock();render()};
};
function keepScroll(){const y=window.scrollY;render();window.scrollTo(0,y)}

/* ============ BOOT ============ */
R=parse(S.route||"home");if(R.tab==="words"&&R.a==="pairs")R.a=null;
render();
if("serviceWorker" in navigator&&/github\.io$|^localhost$/.test(location.hostname)){navigator.serviceWorker.register("sw.js").catch(()=>{})}
})();
