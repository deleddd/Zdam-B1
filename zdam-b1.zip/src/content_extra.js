/* ---------- more multiple-choice grammar ---------- */
GRAM.push(
["Dopełniacz","Potrzebuję ___ (pomoc).",["pomocy","pomoc","pomocą"],0,"potrzebować + dopełniacz: pomoc → pomocy."],
["Dopełniacz","Nie lubię ___ (ten film).",["tego filmu","ten film","tym filmem"],0,"Отрицание → dopełniacz: ten film → tego filmu."],
["Dopełniacz","Kupiłem kilo ___ (jabłka).",["jabłek","jabłka","jabłkami"],0,"После мер (kilo, litr, dużo, mało) — dopełniacz мн.ч.: jabłek."],
["Dopełniacz","Idę do ___ (dentysta).",["dentysty","dentyście","dentystą"],0,"do + dopełniacz: dentysta → dentysty."],
["Dopełniacz","Na koncert przyszło dużo ___ (ludzie).",["ludzi","ludzie","ludźmi"],0,"dużo + dopełniacz мн.ч.: ludzi."],
["Celownik","Ten film nie podobał ___ się.",["mi","mnie","mną"],0,"podobać się komu? → celownik: mi."],
["Celownik","Pożycz ___ (siostra) samochód.",["siostrze","siostrę","siostry"],0,"pożyczyć komu? → celownik: siostra → siostrze (r → rz)."],
["Celownik","Dzięki ___ (ty) zdałem egzamin.",["tobie","ciebie","tobą"],0,"dzięki + celownik: tobie."],
["Biernik","Mam ___ (siostra) i brata.",["siostrę","siostry","siostrą"],0,"mieć + biernik: siostra → siostrę."],
["Biernik","Idę na ___ (poczta).",["pocztę","poczcie","poczty"],0,"na + куда? → biernik: na pocztę. (Где? → na poczcie.)"],
["Biernik","Poproszę ___ (herbata) z cytryną.",["herbatę","herbaty","herbatą"],0,"poprosić + biernik: herbatę."],
["Narzędnik","Jadę do pracy ___ (rower).",["rowerem","rower","rowerze"],0,"Средство передвижения → narzędnik без предлога: rowerem, tramwajem."],
["Narzędnik","Kot śpi pod ___ (stół).",["stołem","stół","stole"],0,"pod (где?) + narzędnik: pod stołem."],
["Narzędnik","On chce zostać ___ (lekarz).",["lekarzem","lekarz","lekarza"],0,"zostać + narzędnik: lekarzem."],
["Narzędnik","Spotkałem się z ___ (przyjaciele).",["przyjaciółmi","przyjaciół","przyjaciele"],0,"z + narzędnik мн.ч.: przyjaciółmi."],
["Miejscownik","Klucze leżą na ___ (stół).",["stole","stołem","stół"],0,"na (где?) + miejscownik: na stole (ł → l)."],
["Miejscownik","Pracuję w ___ (biuro).",["biurze","biuro","biurem"],0,"w (где?) + miejscownik: w biurze (r → rz)."],
["Miejscownik","Ciągle myślę o ___ (ty).",["tobie","ciebie","ty"],0,"o + miejscownik: o tobie."],
["Miejscownik","Wczoraj byłem na ___ (koncert).",["koncercie","koncert","koncertem"],0,"na (где?) + miejscownik: na koncercie (t → ci)."],
["Aspekt","Często ___ do mamy.",["dzwonię","zadzwonię","zadzwoniłem"],0,"często — повтор → несовершенный вид: dzwonię."],
["Aspekt","Wczoraj nagle ___ telefon.",["zadzwonił","dzwonił","dzwoni"],0,"nagle — одно мгновенное событие → совершенный вид: zadzwonił."],
["Aspekt","Już ___ obiad, możemy jeść.",["ugotowałam","gotowałam","gotuję"],0,"już + результат готов → совершенный вид: ugotowałam."],
["Aspekt","Kiedy ___ obiad, zadzwonił telefon.",["gotowałam","ugotowałam","ugotuję"],0,"Фоновое длительное действие, которое прервали → несов.: gotowałam."],
["Ruch","Co roku ___ na wakacje nad morze.",["jeździmy","jedziemy","pojechaliśmy"],0,"Co roku — регулярно → jeździć: jeździmy."],
["Ruch","Jutro ___ do Krakowa pociągiem.",["pojadę","jeżdżę","chodzę"],0,"Разовая поездка в будущем → pojechać: pojadę."],
["Ruch","Mój syn ma rok i już umie ___.",["chodzić","iść","pójść"],0,"Умение ходить вообще → chodzić."],
["Tryb","___ zarezerwować stolik na sobotę.",["Chciałbym","Chcę bym","Chciałem by"],0,"Вежливая просьба: chciałbym / chciałabym."],
["Tryb","Na twoim miejscu ___ do lekarza.",["poszedłbym","pójdę","szedłem"],0,"Совет «на твоём месте» → tryb przypuszczający: poszedłbym."],
["Tryb","Gdyby nie padało, ___ na spacer.",["poszlibyśmy","pójdziemy","szliśmy"],0,"gdyby → tryb przypuszczający: poszlibyśmy."],
["Liczebniki","Mam ___ koty.",["dwa","dwóch","dwie"],0,"kot — м.р., не человек → dwa koty."],
["Liczebniki","Mam ___ siostry.",["dwie","dwa","dwóch"],0,"Ж.р. → dwie: dwie siostry."],
["Liczebniki","Kupiłem pięć ___ (bilet).",["biletów","bilety","biletach"],0,"5+ → dopełniacz мн.ч.: pięć biletów."],
["Liczebniki","Spotkanie jest ___ marca.",["dwudziestego pierwszego","dwadzieścia jeden","dwudziesty pierwszy"],0,"Дата — порядковое числительное в dopełniacz: dwudziestego pierwszego marca."],
["Przyimki","W wakacje jadę ___ Niemiec.",["do","na","w"],0,"Страны: do + dopełniacz (do Niemiec, do Francji)."],
["Przyimki","Byłem w zeszłym roku ___ Węgrzech.",["na","w","do"],0,"Некоторые страны с na: na Węgrzech, na Ukrainie, na Litwie."],
["Przyimki","Moi dziadkowie mieszkają ___ wsi.",["na","w","do"],0,"Устойчиво: na wsi (но w mieście)."],
["Przyimki","Uczyłem się polskiego ___ dwa lata.",["przez","od","za"],0,"Длительность в прошлом (сколько времени?) → przez: przez dwa lata."],
["Przyimki","Ten prezent jest ___ ciebie.",["dla","do","na"],0,"Для кого? → dla + dopełniacz."],
["Inne","To jest ___ książka.",["moja","mój","moje"],0,"książka — ж.р. → moja."],
["Inne","To najstarszy dom ___ okolicy.",["w","na","z"],0,"w okolicy — в районе."],
["Inne","___ się nazywasz?",["Jak","Co","Kto"],0,"Jak się nazywasz? — дословно «как ты называешься»."],
["Inne","Myślę, ___ masz rację.",["że","żeby","czy"],0,"Утверждение → że: myślę, że…"],
["Inne","Chcę, ___ przyszedł jutro.",["żebyś","że","czy"],0,"chcieć, żeby + форма прош. времени: chcę, żebyś przyszedł."]
);

/* ---------- typed forms: [sentence, hint, answers "a|b", explanation] ---------- */
const FORMS=[
["Nie mam ___ .","samochód","samochodu","Отрицание → dopełniacz."],
["Rozmawiam z ___ .","szef","szefem","z (с кем) → narzędnik."],
["Mieszkam w ___ .","Warszawa","Warszawie","w (где) → miejscownik: Warszawa → Warszawie."],
["Daję prezent ___ .","żona","żonie","komu? → celownik."],
["Lubię ___ .","czekolada","czekoladę","lubić + biernik."],
["Jestem ___ .","student","studentem","być + narzędnik."],
["Szukam ___ .","klucze","kluczy","szukać + dopełniacz мн.ч."],
["Wczoraj ___ w kinie.","ja (m.), być","byłem","Прошедшее время, 1 лицо м.р.: byłem (ж.р. byłam)."],
["Wczoraj ona ___ list.","napisać","napisała","Прош. время, ж.р.: napisała."],
["Jutro ___ do ciebie.","ja, zadzwonić","zadzwonię","Совершенный вид в форме настоящего = будущее."],
["Oni ___ w Poznaniu.","mieszkać","mieszkają","Настоящее время, 3 лицо мн.ч.: mieszkają."],
["My ___ po polsku.","mówić","mówimy","1 лицо мн.ч.: mówimy."],
["Co ty ___ ?","robić","robisz","2 лицо ед.ч.: robisz."],
["Gdybym miał czas, ___ nad morze.","ja (m.), pojechać","pojechałbym","Tryb przypuszczający: pojechał + bym."],
["Mam pięć ___ .","kot","kotów","5+ → dopełniacz мн.ч."],
["Mieszkam tu od trzech ___ .","miesiąc","miesięcy","od + dopełniacz мн.ч.: miesięcy."],
["To jest samochód mojego ___ .","brat","brata","Чей? → dopełniacz."],
["Idę z ___ na spacer.","pies","psem","z + narzędnik: psem (беглое e)."],
["Opowiedz mi o swojej ___ .","podróż","podróży","o + miejscownik: podróży."],
["Ona jest ___ niż jej siostra.","wysoki","wyższa","Сравнительная степень, ж.р.: wyższa."],
["To ___ restauracja w mieście.","dobry (najw.)","najlepsza","Превосходная степень: najlepszy → najlepsza."],
["Wczoraj my ___ do kina.","pójść","poszliśmy","Прош. время мн.ч.: poszliśmy."],
["___ drzwi, proszę!","zamknąć, ty","zamknij","Повелительное наклонение: zamknij."],
["Nie ___ się!","martwić, ty","martw","Повелительное: martw się."],
["Często myślę o ___ .","moja mama","mojej mamie","o + miejscownik: mojej mamie."],
["Dzwonię do ___ .","moi rodzice","moich rodziców","do + dopełniacz мн.ч.: moich rodziców."],
["Jestem zadowolony z ___ .","nowa praca","nowej pracy","z (из, от) + dopełniacz."],
["Interesuję się ___ .","polska historia","polską historią","interesować się + narzędnik."],
["Wczoraj oni ___ cały dzień.","pracować","pracowali","Прош. время, мужск.-личн. мн.ч.: pracowali."],
["Dziewczyny ___ do domu późno.","wrócić","wróciły|wrocily","Прош. время, неличн. мн.ч. (женщины): wróciły."],
["Proszę ___ ten formularz.","wypełnić","wypełnić","Proszę + инфинитив."],
["Nie ___ wczoraj w pracy.","ja (ż.), być","byłam","Прош. время, 1 лицо ж.р.: byłam."]
];

/* ---------- word order: [canonical, alternatives[], RU] ---------- */
const ORDER=[
["Codziennie jeżdżę do pracy tramwajem.",["Jeżdżę codziennie do pracy tramwajem.","Codziennie jeżdżę tramwajem do pracy."],"Каждый день я езжу на работу на трамвае."],
["Czy mogę zapłacić kartą?",[],"Можно оплатить картой?"],
["Muszę złożyć wniosek w urzędzie.",["W urzędzie muszę złożyć wniosek."],"Мне нужно подать заявление в управлении."],
["Nie mam czasu, bo dużo pracuję.",[],"У меня нет времени, потому что я много работаю."],
["Gdybym miał więcej czasu, czytałbym więcej.",[],"Если бы у меня было больше времени, я бы больше читал."],
["Chciałbym zarezerwować stolik na sobotę.",["Na sobotę chciałbym zarezerwować stolik."],"Я хотел бы забронировать столик на субботу."],
["Od trzech lat mieszkam w Poznaniu.",["Mieszkam w Poznaniu od trzech lat.","W Poznaniu mieszkam od trzech lat."],"Я живу в Познани три года."],
["Interesuję się historią i sztuką.",[],"Я интересуюсь историей и искусством."],
["Jutro pójdziemy do kina.",["Pójdziemy jutro do kina.","Do kina pójdziemy jutro."],"Завтра мы пойдём в кино."],
["Proszę wypełnić ten formularz do piątku.",["Proszę wypełnić do piątku ten formularz."],"Пожалуйста, заполните этот бланк до пятницы."],
["Moim zdaniem praca zdalna jest wygodna.",["Praca zdalna jest moim zdaniem wygodna."],"По-моему, удалённая работа удобна."],
["Zanim wyjdziesz, zamknij okno.",["Zamknij okno, zanim wyjdziesz."],"Прежде чем выйти, закрой окно."],
["Nie wiem, gdzie jest dworzec.",[],"Я не знаю, где вокзал."],
["Wczoraj byłem u lekarza.",["Byłem wczoraj u lekarza.","U lekarza byłem wczoraj."],"Вчера я был у врача."],
["Czy może Pan mówić wolniej?",[],"Не могли бы вы говорить медленнее?"],
["Bardzo się cieszę, że przyjechałeś.",["Bardzo cieszę się, że przyjechałeś.","Cieszę się bardzo, że przyjechałeś."],"Я очень рад, что ты приехал."]
];

/* ---------- find the error: [sentence, wrong word index, correct form, explanation] ---------- */
const ERRORS=[
["Nie mam samochód.",2,"samochodu","После отрицания — dopełniacz."],
["Mieszkam w Poznań.",2,"Poznaniu","w (где?) + miejscownik."],
["Jestem nauczyciel.",1,"nauczycielem","być + narzędnik."],
["Interesuję się sport.",2,"sportem","interesować się + narzędnik."],
["Wczoraj ona był w domu.",2,"była","Ж.р. → była."],
["Mam dwa siostry.",1,"dwie","Ж.р. → dwie."],
["Dziękuję cię za pomoc.",1,"ci","dziękować komu? → ci."],
["Idę do sklep po chleb.",2,"sklepu","do + dopełniacz."],
["Pomagam mamę w kuchni.",1,"mamie","pomagać komu? → celownik."],
["Codziennie jadę do pracy autobusem.",1,"jeżdżę","Регулярно → jeździć."],
["Wczoraj cały wieczór napisałem list.",3,"pisałem","«Cały wieczór» — процесс → несовершенный вид."],
["Mam trzy psa i kota.",2,"psy","2–4 → mianownik мн.ч.: trzy psy."],
["Spotkajmy się w godzinie ósmej.",2,"o","Время по часам: o godzinie."],
["Zapisałem się do kurs angielskiego.",2,"na","zapisać się NA kurs."],
["Boję się pies sąsiada.",2,"psa","bać się + dopełniacz."],
["Lubię kawy z mlekiem.",1,"kawę","lubić + biernik."],
["On jest wyższy od mnie niż brat.",3,"niż|od","Сравнение: wyższy od kogoś ИЛИ wyższy niż ktoś — не оба сразу. Лишнее «od mnie»."]
];
ERRORS.pop(); // keep only single-word cases

/* ---------- more reading ---------- */
READ.push(
{t:"Komunikat: zmiana rozkładu",x:"Uwaga, pasażerowie! Od 1 grudnia do 15 stycznia z powodu remontu torów tramwaje linii 5 i 13 nie będą jeździć ulicą Głogowską. Zamiast nich kursować będą autobusy zastępcze oznaczone literą T. Autobusy odjeżdżają co dziesięć minut, a w nocy co pół godziny. Bilety tramwajowe są ważne w autobusach zastępczych. Szczegółowy rozkład jazdy znajduje się na przystankach i w aplikacji przewoźnika.",
 q:[["Remont potrwa około sześciu tygodni.",["Prawda","Fałsz"],0],["Autobusy zastępcze są oznaczone literą T.",["Prawda","Fałsz"],0],["W nocy autobusy jeżdżą co dziesięć minut.",["Prawda","Fałsz"],1],["Na autobus zastępczy trzeba kupić osobny bilet.",["Prawda","Fałsz"],1]]},
{t:"Regulamin siłowni",x:"Siłownia FitPoint jest czynna codziennie od 6:00 do 23:00, a w niedziele i święta od 8:00 do 20:00. Przed pierwszym treningiem każdy klient musi wypełnić ankietę zdrowotną. Na salę ćwiczeń wchodzimy wyłącznie w czystym obuwiu sportowym. Ręcznik jest obowiązkowy. Szafek w szatni można używać tylko w czasie treningu – rzeczy pozostawione na noc zostaną usunięte. Osoby poniżej 16 lat mogą ćwiczyć tylko pod opieką dorosłego.",
 q:[["O której siłownia zamyka się w niedzielę?",["o 23:00","o 20:00","o 22:00"],1],["Co trzeba zrobić przed pierwszym treningiem?",["kupić ręcznik","wypełnić ankietę","zapisać się na zajęcia"],1],["Co stanie się z rzeczami zostawionymi w szafce na noc?",["zostaną w recepcji","zostaną usunięte","będą bezpieczne"],1],["Piętnastolatek może ćwiczyć:",["sam","z dorosłym","tylko w weekend"],1]]},
{t:"List od przyjaciółki",x:"Kochana Marto! Przepraszam, że tak długo nie pisałam. W październiku zmieniłam pracę i ciągle brakuje mi czasu. Teraz pracuję w biurze podróży w centrum Wrocławia. Praca jest ciekawa, ale muszę dużo rozmawiać przez telefon po angielsku i po niemiecku, a to na początku było dla mnie stresujące. Na szczęście mam bardzo miłych kolegów. W grudniu mam tydzień urlopu i chciałabym Cię odwiedzić w Gdańsku. Czy będziesz wtedy w domu? Napisz, jaki termin Ci pasuje. Ściskam, Kasia",
 q:[["Dlaczego Kasia długo nie pisała?",["była chora","ma dużo pracy","wyjechała za granicę"],1],["Gdzie pracuje Kasia?",["w szkole","w biurze podróży","w banku"],1],["Co było dla niej stresujące?",["rozmowy w obcych językach","dojazdy do pracy","koledzy"],0],["Co planuje Kasia?",["zmienić pracę","przyjechać do Gdańska w grudniu","wziąć urlop w październiku"],1]]},
{t:"Polacy i rowery",x:"W ostatnich latach w polskich miastach powstało wiele nowych dróg dla rowerów. W dużych miastach działają też systemy rowerów miejskich, które można wypożyczyć przez aplikację. Dla wielu mieszkańców rower stał się podstawowym środkiem transportu – jest tańszy niż samochód i często szybszy w godzinach szczytu. Nie wszyscy są jednak zadowoleni. Kierowcy narzekają, że przez nowe ścieżki rowerowe na ulicach jest mniej miejsca, a piesi skarżą się na rowerzystów jeżdżących po chodnikach. Eksperci uważają, że rozwiązaniem jest lepsze planowanie i wzajemny szacunek.",
 q:[["Jak można wypożyczyć rower miejski?",["w urzędzie","przez aplikację","w sklepie"],1],["Dlaczego wiele osób wybiera rower?",["jest modny","jest tańszy i szybszy w korkach","jest obowiązkowy"],1],["Na co skarżą się piesi?",["na hałas","na rowerzystów na chodnikach","na brak ścieżek"],1],["Co proponują eksperci?",["zakazać rowerów","lepsze planowanie i szacunek","więcej parkingów"],1]]},
{t:"Ogłoszenia drobne",x:"A) Sprzedam rower górski, mało używany, cena do negocjacji. Telefon po 18:00. B) Szukam opiekunki do dwójki dzieci (4 i 7 lat) na trzy popołudnia w tygodniu. Wymagana znajomość języka polskiego. C) Korepetycje z matematyki dla uczniów szkół średnich. Pierwsza lekcja gratis. D) Oddam za darmo kanapę w dobrym stanie. Odbiór własny, trzecie piętro bez windy.",
 q:[["Gdzie można dostać coś za darmo?",["A","B","C","D"],3],["Kto szuka pracownika?",["A","B","C","D"],1],["W którym ogłoszeniu cena nie jest stała?",["A","B","C","D"],0],["Gdzie pierwsze spotkanie nic nie kosztuje?",["A","B","C","D"],2]]}
);

/* ---------- listening dialogues (TTS) ---------- */
const LISTEN=[
{t:"Na dworcu",x:["Dzień dobry, poproszę bilet do Krakowa na najbliższy pociąg.","Najbliższy odjeżdża o czternastej dwadzieścia, ale nie ma już miejsc siedzących. Następny jest o piętnastej pięć.","To poproszę na piętnastą pięć. Ile kosztuje?","Normalny osiemdziesiąt dziewięć złotych, ze zniżką studencką czterdzieści trzy.","Normalny, proszę. Z którego peronu?","Z peronu drugiego, tor czwarty."],
 q:[["O której odjeżdża pociąg pasażera?",["14:20","15:05","15:50"],1],["Ile zapłaci pasażer?",["43 zł","89 zł","98 zł"],1],["Z którego peronu odjeżdża pociąg?",["z drugiego","z czwartego","z trzeciego"],0]]},
{t:"Rejestracja do lekarza",x:["Przychodnia Zdrowie, słucham.","Dzień dobry, chciałbym zapisać się do lekarza rodzinnego. Od trzech dni mam gorączkę i boli mnie gardło.","Na dzisiaj nie mamy już terminów. Może być jutro o ósmej trzydzieści?","Niestety rano pracuję. Czy jest coś po południu?","Jutro o szesnastej piętnaście u doktor Nowak.","Świetnie, dziękuję.","Proszę zabrać ze sobą dowód osobisty."],
 q:[["Co dolega pacjentowi?",["ból głowy","gorączka i ból gardła","ból brzucha"],1],["Kiedy jest wizyta?",["dziś o 16:15","jutro o 8:30","jutro o 16:15"],2],["Co pacjent ma zabrać?",["dowód osobisty","skierowanie","wyniki badań"],0]]},
{t:"Mieszkanie do wynajęcia",x:["Dzwonię w sprawie ogłoszenia. Czy mieszkanie na Wildzie jest jeszcze wolne?","Tak. To dwa pokoje, czterdzieści osiem metrów, trzecie piętro z windą.","A ile wynosi czynsz?","Dwa tysiące dwieście złotych plus rachunki, mniej więcej trzysta złotych miesięcznie. Kaucja to jeden czynsz.","Czy mogę przyjść obejrzeć mieszkanie w sobotę?","W sobotę wyjeżdżam, ale w piątek po siedemnastej mogę pokazać."],
 q:[["Ile pokoi ma mieszkanie?",["dwa","trzy","cztery"],0],["Ile wynosi czynsz bez rachunków?",["1800 zł","2200 zł","2500 zł"],1],["Kiedy można obejrzeć mieszkanie?",["w sobotę","w piątek po 17:00","w piątek rano"],1]]},
{t:"Prognoza pogody",x:["A teraz prognoza pogody na weekend.","W sobotę na północy kraju będzie pochmurno i deszczowo, temperatura nie przekroczy ośmiu stopni.","Na południu pogodnie, nawet do dwunastu stopni.","W niedzielę w całej Polsce ochłodzenie, w nocy przymrozki, a w górach możliwe opady śniegu.","Kierowców prosimy o ostrożność."],
 q:[["Gdzie w sobotę będzie cieplej?",["na północy","na południu","w górach"],1],["Jaka będzie niedziela?",["cieplejsza","chłodniejsza","burzowa"],1],["Gdzie może padać śnieg?",["w górach","na północy","nad morzem"],0]]},
{t:"Reklamacja w sklepie",x:["Dzień dobry, kupiłem u państwa te buty dwa tygodnie temu i już się rozkleiły.","Ma pan paragon?","Tak, proszę.","Możemy przyjąć reklamację. Odpowiedź dostanie pan w ciągu czternastu dni. Woli pan wymianę czy zwrot pieniędzy?","Wolałbym zwrot pieniędzy.","Dobrze, proszę tu podpisać."],
 q:[["Co się stało z butami?",["są za małe","rozkleiły się","mają zły kolor"],1],["Kiedy klient dostanie odpowiedź?",["w ciągu 7 dni","w ciągu 14 dni","w ciągu 30 dni"],1],["Czego chce klient?",["wymiany","zwrotu pieniędzy","rabatu"],1]]},
{t:"Komunikat w sklepie",x:["Szanowni klienci, informujemy, że w związku ze świętem w czwartek nasz sklep będzie zamknięty.","W piątek zapraszamy od dziewiątej do dwudziestej pierwszej.","Przypominamy też o promocji: przy zakupach powyżej stu złotych drugi produkt z działu kosmetyków otrzymają Państwo za pół ceny."],
 q:[["Kiedy sklep będzie zamknięty?",["w czwartek","w piątek","w sobotę"],0],["Do której sklep jest otwarty w piątek?",["do 20:00","do 21:00","do 22:00"],1],["Na czym polega promocja?",["drugi kosmetyk za pół ceny","wszystko 50% taniej","darmowa dostawa"],0]]},
{t:"Rozmowa o pracę",x:["Dzień dobry, proszę usiąść. Dlaczego chce pan u nas pracować?","Szukam pracy bliżej domu. Teraz dojeżdżam godzinę w jedną stronę.","Rozumiem. Jakie ma pan doświadczenie?","Pięć lat pracowałem w magazynie, ostatnie dwa lata jako kierownik zmiany.","Praca u nas jest na trzy zmiany. Czy to dla pana problem?","Nie, mogę pracować także w nocy. Kiedy mógłbym zacząć?","Od pierwszego grudnia."],
 q:[["Dlaczego kandydat zmienia pracę?",["chce więcej zarabiać","chce pracować bliżej domu","nie lubi szefa"],1],["Ile lat był kierownikiem zmiany?",["dwa","pięć","trzy"],0],["Od kiedy może zacząć pracę?",["od 1 listopada","od 1 grudnia","od zaraz"],1]]},
{t:"W urzędzie",x:["Dzień dobry, chciałbym się zameldować.","Proszę wypełnić ten formularz i dać mi umowę najmu.","Mam umowę, ale tylko w telefonie.","Niestety, potrzebujemy papierowej kopii. Może pan wydrukować ją w punkcie ksero na parterze.","A czy muszę potem stać w kolejce jeszcze raz?","Nie, proszę wrócić od razu do tego okienka."],
 q:[["Co chce załatwić klient?",["meldunek","paszport","prawo jazdy"],0],["Czego brakuje?",["zdjęcia","papierowej umowy","podpisu"],1],["Gdzie można wydrukować dokument?",["na parterze","na pierwszym piętrze","poza urzędem"],0]]}
];

/* ---------- writing: more tasks and model answers ---------- */
WRITE.push(
{t:"E-mail do szkoły językowej",task:"Chcesz zapisać się na kurs polskiego. Zapytaj o szczegóły.",pts:["przedstaw się","jaki kurs cię interesuje","zapytaj o cenę i godziny","zapytaj o termin rozpoczęcia"],kind:"form"},
{t:"Przeprosiny",task:"Nie przyszedłeś na spotkanie z kolegą. Napisz do niego.",pts:["przeproś","wyjaśnij, co się stało","zaproponuj nowy termin","zakończ przyjaźnie"],kind:"inf"}
);
const MODELS=[
"Cześć Tomek!\nW sobotę 14 grudnia kończę 30 lat i chciałbym to uczcić. Zapraszam Cię na imprezę do mojego mieszkania na ulicy Głogowskiej 25. Zaczynamy o 19:00. Najłatwiej dojechać tramwajem numer 5 – wysiądź na przystanku Rynek Łazarski, to dwie minuty pieszo. Jedzenie przygotuję sam, ale jeśli chcesz, przynieś coś do picia. Prezent nie jest potrzebny! Daj znać do środy, czy przyjdziesz, bo muszę wiedzieć, ile osób będzie.\nDo zobaczenia!\nAdam",
"Szanowni Państwo,\nuprzejmie informuję, że od 5 listopada w naszym bloku przy ulicy Słowackiego 12 nie działa winda. To duży problem dla mieszkańców, szczególnie dla osób starszych i rodzin z małymi dziećmi. Moja sąsiadka z dziewiątego piętra nie wychodzi z domu, bo nie może chodzić po schodach. Zwracam się z prośbą o szybką naprawę windy. Proszę o informację, kiedy problem zostanie rozwiązany. Mój numer telefonu: 600 123 456.\nZ poważaniem\nAdam Kowalczyk, mieszkanie 34",
"Szanowni Państwo,\n10 października kupiłem w Państwa sklepie internetowym słuchawki bezprzewodowe (zamówienie nr 4581). Po tygodniu lewa słuchawka przestała działać, chociaż używałem ich zgodnie z instrukcją. Dlatego składam reklamację i proszę o zwrot pieniędzy. Jeśli zwrot nie jest możliwy, zgodzę się na wymianę na nowy produkt. W załączniku przesyłam zdjęcie paragonu. Proszę o kontakt mailowy lub telefoniczny: 600 123 456.\nZ poważaniem\nAdam Kowalczyk",
"Moim zdaniem nauka języków przez internet ma sens, ale nie może być jedyną metodą. Przede wszystkim jest wygodna: można się uczyć w domu, w tramwaju albo w przerwie w pracy. Poza tym w internecie jest dużo darmowych materiałów, na przykład filmy, podcasty i aplikacje. Z drugiej strony trudno jest nauczyć się mówić bez kontaktu z drugim człowiekiem, a aplikacja nie poprawi naszych błędów tak jak nauczyciel. Podsumowując, uważam, że internet to dobre uzupełnienie kursu, ale warto też rozmawiać z ludźmi na żywo.",
"Cześć Ania!\nPrzepraszam, że tak długo nie pisałem, ale od miesiąca pracuję w nowej firmie i mam mało czasu. Pracuję jako grafik w agencji reklamowej w centrum Poznania. Do moich obowiązków należy przygotowywanie projektów dla klientów i kontakt z drukarnią. Bardzo podoba mi się zespół – wszyscy są mili i pomocni. Nie podoba mi się tylko to, że często mamy nadgodziny. W przyszłości chciałbym prowadzić własne projekty. A co u Ciebie?\nPozdrawiam serdecznie\nAdam",
"Szukam współlokatora!\nDo wynajęcia pokój 14 m² w trzypokojowym mieszkaniu na Jeżycach, 10 minut tramwajem od centrum. Mieszkanie jest umeblowane, z balkonem i pralką. Cena: 1300 zł miesięcznie + rachunki (ok. 200 zł). Szukam osoby pracującej lub studiującej, niepalącej, która lubi porządek. Mieszkam z kotem, więc osoba z alergią nie da rady. Wolny od 1 grudnia. Kontakt: 600 123 456 (najlepiej SMS) lub mail: pokoj.jezyce@poczta.pl",
"Szanowni Państwo,\nnazywam się Adam Kowalczyk i od dwóch lat mieszkam w Poznaniu. Chciałbym zapisać się na kurs języka polskiego na poziomie B1, ponieważ w przyszłym roku planuję zdawać egzamin certyfikatowy. Interesuje mnie kurs wieczorowy, najlepiej dwa razy w tygodniu. Proszę o informację, ile kosztuje kurs i w jakich godzinach odbywają się zajęcia. Chciałbym też zapytać, kiedy zaczyna się najbliższy kurs i czy trzeba napisać test kwalifikacyjny.\nZ poważaniem\nAdam Kowalczyk",
"Cześć Marek!\nBardzo Cię przepraszam za wczoraj. Wiem, że czekałeś na mnie w kawiarni prawie godzinę. Niestety po pracy zepsuł mi się samochód, a telefon był rozładowany, więc nie mogłem do Ciebie zadzwonić. Głupio mi, że tak wyszło. Może spotkamy się w sobotę o 17:00 w tym samym miejscu? Tym razem ja stawiam kawę i ciasto! Daj znać, czy Ci pasuje.\nJeszcze raz przepraszam!\nAdam"
];
WRITE.forEach((w,i)=>w.model=MODELS[i]);

/* ---------- more speaking ---------- */
SPEAK.push(
["Opowiedz o swojej pracy: co robisz, co lubisz, a czego nie?","Работа"],
["Jak wygląda twój typowy dzień?","Распорядок дня"],
["Opisz swoje ulubione miejsce w mieście, w którym mieszkasz.","Описание места"],
["Co jest dla ciebie najtrudniejsze w języku polskim? Dlaczego?","Опыт изучения языка"],
["Jesteś w restauracji. Zamów jedzenie i zapytaj o rachunek.","Ролевая: ресторан"],
["Chcesz wynająć mieszkanie. Zadzwoń do właściciela i zapytaj o szczegóły.","Ролевая: аренда"],
["Czy ludzie powinni pracować mniej? Uzasadnij swoje zdanie.","Мнение"],
["Opowiedz o najlepszym prezencie, jaki dostałeś.","Прошедшее время"]
);
