"""Build the GitHub Pages site (repo root) from src/page.html.
src/page.html is the body-only page also used for the Claude artifact."""
import json, os, re
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
page = open(os.path.join(ROOT, "src/page.html"), encoding="utf-8").read()
title = re.search(r"<title>(.*?)</title>", page).group(1)
page = page.replace(f"<title>{title}</title>", "")

head = f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{title}</title>
<meta name="description" content="Подготовка к государственному экзамену по польскому B1: слова, грамматика, аудирование, письмо, пробный экзамен.">
<meta name="theme-color" content="#142033">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" href="icon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Zdam B1">
<style>:root{{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}}body{{margin:0;font:14px system-ui,sans-serif}}img{{max-width:100%}}[hidden]{{display:none!important}}</style>
"""
# everything up to </style> of the page goes in <head>, the rest in <body>
cut = page.index("</style>") + len("</style>")
html = head + page[:cut] + "\n</head>\n<body>\n" + page[cut:] + "</body>\n</html>\n"
open(os.path.join(ROOT, "index.html"), "w", encoding="utf-8").write(html)

# icons
svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="112" fill="#142033"/><rect x="96" y="176" width="320" height="160" rx="36" fill="#F0B814"/><text x="256" y="302" font-family="Arial,Helvetica,sans-serif" font-size="128" font-weight="700" text-anchor="middle" fill="#1A1300">B1</text></svg>'
open(os.path.join(ROOT, "icon.svg"), "w").write(svg)
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 128)
def icon(size, name, radius=112):
    s = 512
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, s - 1, s - 1], radius=radius, fill="#142033")
    d.rounded_rectangle([96, 176, 416, 336], radius=36, fill="#F0B814")
    d.text((256, 258), "B1", font=font, fill="#1A1300", anchor="mm")
    im.resize((size, size), Image.LANCZOS).save(os.path.join(ROOT, name))
icon(192, "icon-192.png"); icon(512, "icon-512.png"); icon(180, "apple-touch-icon.png", radius=0)

manifest = {"name": "Zdam B1 — польский к экзамену", "short_name": "Zdam B1", "start_url": "./", "scope": "./",
            "display": "standalone", "background_color": "#EDF0F4", "theme_color": "#142033", "lang": "ru",
            "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
                      {"src": "icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]}
open(os.path.join(ROOT, "manifest.webmanifest"), "w").write(json.dumps(manifest, ensure_ascii=False, indent=2))

files = ["./", "index.html", "js/words.js", "js/content.js", "js/app.js", "manifest.webmanifest", "icon.svg", "icon-192.png", "icon-512.png", "apple-touch-icon.png"]
ver = str(abs(hash(html + open(os.path.join(ROOT, "js/app.js"), encoding="utf-8").read())) % 10**8)
sw = f"""// offline cache for Zdam B1
const CACHE="zdam-b1-{ver}";
const FILES={json.dumps(files)};
self.addEventListener("install",e=>{{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)));self.skipWaiting()}});
self.addEventListener("activate",e=>{{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))));self.clients.claim()}});
self.addEventListener("fetch",e=>{{if(e.request.method!=="GET")return;
  e.respondWith(fetch(e.request).then(r=>{{const copy=r.clone();if(r.ok&&new URL(e.request.url).origin===location.origin)caches.open(CACHE).then(c=>c.put(e.request,copy));return r}}).catch(()=>caches.match(e.request)))}});
"""
open(os.path.join(ROOT, "sw.js"), "w").write(sw)
print("built", len(html), "bytes; cache", ver)
